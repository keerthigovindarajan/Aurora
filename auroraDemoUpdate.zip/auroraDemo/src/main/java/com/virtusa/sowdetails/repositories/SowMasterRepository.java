package com.virtusa.sowdetails.repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.virtusa.sowdetails.models.SowMasterModel;

@Repository
public interface SowMasterRepository extends JpaRepository<SowMasterModel, String> {

	@Query(value = "select * from sowmaster_details s where s.Sector=:sector", nativeQuery = true)
	List<SowMasterModel> findBySector(@PathVariable("sector") String sector);

	@Query(value = "select * from sowmaster_details s where s.Status=:status", nativeQuery = true)
	List<SowMasterModel> findByStatus(@PathVariable("status") String status);
	
	@Modifying
	@Transactional
	@Query(value = "update sowmaster_details s set s.Status=:status,s.Tenure=:tenure where s.SOW_ID=:id", nativeQuery = true)
	void update(@PathVariable("sowId") String id,@PathVariable("status") String status,@PathVariable("tenure") int tenure);

	

}
