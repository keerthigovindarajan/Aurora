package com.virtusa.sowdetails.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;

@Service
public class SowMasterService {
	@Autowired
	private SowMasterRepository repository;

	public void setRepository(SowMasterRepository repository) {
		this.repository = repository;
	}

	// insert the sowMasterDetails
	public SowMasterModel saveDetails(@RequestBody SowMasterModel sowMasterModel) {
		sowMasterModel = repository.save(sowMasterModel);

		return sowMasterModel;
	}

	
	// insert the multiple sowMasterDetails
		public List<SowMasterModel> saveBulkDetails(@RequestBody List<SowMasterModel> sowMasterModel) {
			sowMasterModel = repository.saveAll(sowMasterModel);

			return sowMasterModel;
		}
	// get the sowmasterDetails
	public List<SowMasterModel> getAllDetails() {

		return repository.findAll();

	}

	// get the sowmasterDetails based on sowid
	public Optional<SowMasterModel> getDetails(@PathVariable String sowid) {

		return repository.findById(sowid);

	}

	// get the sowmasterDetails based on sector
	public List<SowMasterModel> getDetailsBySector(@PathVariable String sector) {

		return repository.findBySector(sector);

	}
	
	// get the sowmasterDetails based on status
		public List<SowMasterModel> getDetailsByStatus(@PathVariable String status) {

			return repository.findByStatus(status);

		}
		
		// update Multiple sowMasterDetails
		public void updateMultipleRowDetails(@RequestBody List<SowMasterModel> sowMasterModel) {

			for(SowMasterModel model:sowMasterModel)
			{
				repository.update(model.getSowId(),model.getStatus(),model.getTenure());
			}
		}

}
