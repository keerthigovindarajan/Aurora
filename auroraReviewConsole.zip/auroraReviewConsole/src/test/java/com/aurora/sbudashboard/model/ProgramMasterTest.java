package com.aurora.sbudashboard.model;

import java.sql.Date;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
public class ProgramMasterTest {

	
	@InjectMocks
	ProgramMaster model = new ProgramMaster();
	
	Date date = new Date(01-10-2020);
	@Before
	public void setUp() {
		model = new ProgramMaster();
		model.getAuroraProgramSeq();
		model.getCreatedBy(); 
		model.getCreatedDate();
		model.getModifiedBy();
		model.getModifiedDate();
		model.getProgramManager();
		model.getProgramName();
		model.setAuroraProgramSeq(1);
		model.setCreatedBy("name");
		model.setCreatedDate(date);
		model.setModifiedBy("name");
		model.setProgramManager("managername");
		model.setProgramName("name");
		model.setModifiedDate(date);
	}
	
	@Test
	public void getAuroraProgramSeq() {
		model.getAuroraProgramSeq();
	}
}
