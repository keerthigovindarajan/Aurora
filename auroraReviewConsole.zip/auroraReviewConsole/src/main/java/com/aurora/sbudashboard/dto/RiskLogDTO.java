package com.aurora.sbudashboard.dto;


public interface RiskLogDTO {
	
	 String getProject();
	 String getRiskCategory();
	 String getRiskIdentified();
	 String getRiskIdentifiedBy(); 
	 String getRiskInitiator();
	 String getRiskIDentifiedOn();
	 String getImpact();
	 String getRiskDescription();
	 String getRemediation();
	 String getStatus();
	 Integer getChorusAlertID();
	 Character getDxTAlert();
	 String getRAG(); 
}
