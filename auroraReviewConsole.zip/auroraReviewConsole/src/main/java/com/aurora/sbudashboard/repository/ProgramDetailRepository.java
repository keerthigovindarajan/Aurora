package com.aurora.sbudashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.aurora.sbudashboard.dto.ProgramDetailDTO;
import com.aurora.sbudashboard.model.ProgramMaster;

@Repository
public interface ProgramDetailRepository extends JpaRepository<ProgramMaster, Integer>{

	@Query(value ="\r\n" + 
			"select \r\n" + 
			"	*\r\n" + 
			"    from(\r\n" + 
			"select   \r\n" + 
			"	Program_Name,\r\n" + 
			"    Project_Name,\r\n" + 
			"    COUNT(Project_Name) AS Risks,\r\n" + 
			"    SUM(margin) / COUNT(Project_Name) AS Margin,\r\n" + 
			"    SUM(Past_Due_RRs) / COUNT(Project_Name) AS PastDueRRs,\r\n" + 
			"    SUM(Ageing_Of_PastDue_RRs) / COUNT(Project_Name) AS AgeingOfPastDueRRs,\r\n" + 
			"    SUM(Churn_Attrition_Count) / COUNT(Project_Name) AS ChurnAttritionCount,\r\n" + 
			"    SUM(Revenue) / COUNT(Project_Name) AS Revenue,\r\n" + 
			"    count(if( DxT_Alert ='Y',DxT_Alert,NULL)) as DxTAlert \r\n" + 
			"    from (\r\n" + 
			"    SELECT \r\n" + 
			"    pmr.Program_Name,\r\n" + 
			"    pm.Project_Name,\r\n" + 
			"    pli.margin,\r\n" + 
			"    pli.Past_Due_RRs,\r\n" + 
			"    pli.Ageing_Of_PastDue_RRs,\r\n" + 
			"    pli.Churn_Attrition_Count,\r\n" + 
			"    pli.Revenue,\r\n" + 
			"    rl.DxT_Alert\r\n" + 
			"FROM\r\n" + 
			"    \r\n" + 
			"    rag_status rag,\r\n" + 
			"    project_master pm\r\n" + 
			"    INNER JOIN program_master pmr ON pmr.Aurora_Program_Seq = pm.Aurora_Program_Seq_fk,\r\n" + 
			"    risk_log rl\r\n" + 
			"    INNER JOIN project_leading_indicator pli on pli.chorus_code_pk_fk = rl.Chorus_Code\r\n" + 
			"    \r\n" + 
			"WHERE\r\n" + 
			"    pm.Aurora_Project_Seq = rl.Aurora_Project_Seq_fk\r\n" + 
			"	&& rl.Aurora_RAG_Status_Seq_fk = rag.Aurora_RAG_Status_Seq\r\n" + 
			") t group by t.Project_Name ) q where q.Program_Name =:programName",nativeQuery = true)
	List<ProgramDetailDTO> getProgramDetails(@RequestParam("programName") String programName);
}
