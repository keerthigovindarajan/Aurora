package com.aurora.sbudashboard.dto;

public interface ProgramDetailDTO {
	
	String getProject();
	String getRAG();
	Integer getRisks();
	float getMargin();
	Integer getPastDueRRs();
	Integer getPastDueRRsAging();
	Integer getAttritionTopTalentandTopTier();
	Integer getUnbilledRevenue();
	Integer getDxTAlerts();

}
