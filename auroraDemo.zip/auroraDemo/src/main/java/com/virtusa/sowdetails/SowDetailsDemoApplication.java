package com.virtusa.sowdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SowDetailsDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SowDetailsDemoApplication.class, args);
	}

}
