package com.virtusa.sowdetails.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.services.SowMasterService;

@RestController
@RequestMapping("/api/citi-portal")
public class SowMasterController {
	
	@Autowired
	private SowMasterService sowMasterService;

	// saving the sowMaster details

	@CrossOrigin("*")
	@PostMapping("/addDetails")
	public @ResponseBody SowMasterModel addSowMasterDetails(@RequestBody SowMasterModel model)
	{
		return this.sowMasterService.saveDetails(model);
	}

}
