package com.virtusa.sowdetails.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.virtusa.sowdetails.models.SowMasterModel;
import com.virtusa.sowdetails.repositories.SowMasterRepository;

@Service
public class SowMasterService {
	@Autowired
	private SowMasterRepository repository;

	// insert the sowMasterDetails
	public SowMasterModel saveDetails(@RequestBody SowMasterModel sowMasterModel) {
		sowMasterModel = repository.save(sowMasterModel);

		return sowMasterModel;
	}

}
