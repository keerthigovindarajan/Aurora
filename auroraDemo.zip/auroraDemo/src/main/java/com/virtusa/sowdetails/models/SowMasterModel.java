package com.virtusa.sowdetails.models;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.lang.Character;
@Entity
@Table(name="SOWMaster_Details")
public class SowMasterModel {

	@Id
	@Column(name="Sow_Id")
	private Character sowId;
	@Column(name="Contract_Name")
	private char contractName;
	@Column(name="Signed_Effective_Date")
	private Date Signed_Effective_Date;
	public char getSowId() {
		return sowId;
	}
	public void setSowId(char sowId) {
		this.sowId = sowId;
	}
	public char getContractName() {
		return contractName;
	}
	public void setContractName(char contractName) {
		this.contractName = contractName;
	}
	public Date getSigned_Effective_Date() {
		return Signed_Effective_Date;
	}
	public void setSigned_Effective_Date(Date signed_Effective_Date) {
		Signed_Effective_Date = signed_Effective_Date;
	}
	
	
	
	
}
