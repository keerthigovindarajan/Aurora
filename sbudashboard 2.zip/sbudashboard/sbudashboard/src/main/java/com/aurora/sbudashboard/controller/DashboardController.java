package com.aurora.sbudashboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.CriticalRisksRepository;
import com.aurora.sbudashboard.service.RiskSummaryService;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/citi-portal")
public class DashboardController {

	@Autowired
	private CriticalRisksRepository repo;
	@Autowired
	private RiskSummaryService service;

	@GetMapping("/criticalRisks")
	public @ResponseBody List<CriticalRisksDTO> openRisksDetails() {

		List<CriticalRisksDTO> dto = repo.getCriticalRisksDetails();
		return dto;
	}
	

	@GetMapping("/riskSummary")
	public @ResponseBody List<RiskModel> riskSummary() {
		return service.getRiskSummary();
		
	}

}
