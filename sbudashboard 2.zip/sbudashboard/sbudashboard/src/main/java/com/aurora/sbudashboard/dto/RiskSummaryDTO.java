package com.aurora.sbudashboard.dto;

public interface RiskSummaryDTO {

	String getProgram();
	String getCategory();
	Integer getRisk();
	 
}
