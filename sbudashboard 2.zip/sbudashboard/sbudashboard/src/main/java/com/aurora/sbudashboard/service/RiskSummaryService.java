package com.aurora.sbudashboard.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurora.sbudashboard.dto.RiskSummaryDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.RiskSummaryRepository;


@Service
public class RiskSummaryService{

	@Autowired
	private RiskSummaryRepository repository;
	
	public List<RiskModel> getRiskSummary() {
		
		List<RiskSummaryDTO> dto = repository.getRiskSummaryDetails();
		RiskModel ri = new RiskModel();
		List<RiskModel> lir = new ArrayList<>();
		
		int i = 0;
		for (RiskSummaryDTO rm : dto) {

			if (lir.size() == 0) {
				ri = new RiskModel();
				ri.setProgram(rm.getProgram());
					if (rm.getCategory().equals("Project Complexity")) {
						ri.setProjectComplexity(rm.getRisk());
					} else if (rm.getCategory().equals("Status tracking & reporting Rigor")) {
						ri.setStatustrackingandreportingRigor(rm.getRisk());
					}
					lir.add(ri);
				
			}

			else {

				for (i = lir.size() - 1; i < lir.size();) {
					if (!(lir.get(i).getProgram().equals( rm.getProgram()))) {
						ri = new RiskModel();
						ri.setProgram(rm.getProgram());

						if (rm.getCategory().equals("Project Complexity")) {
							ri.setProjectComplexity(rm.getRisk());
						} else if (rm.getCategory().equals("Status tracking & reporting Rigor")) {
							ri.setStatustrackingandreportingRigor(rm.getRisk());
						}
						lir.add(ri);
						break;
					}
					else
					{
						if (rm.getCategory().equals("Project Complexity")) {
							ri.setProjectComplexity(rm.getRisk());
						} else if (rm.getCategory().equals("Status tracking & reporting Rigor")) {
							ri.setStatustrackingandreportingRigor(rm.getRisk());
						}
						break;
					}
				}
			}
		}
		return lir;

		
	}
	

}
