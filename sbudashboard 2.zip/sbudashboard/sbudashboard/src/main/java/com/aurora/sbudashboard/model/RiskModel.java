package com.aurora.sbudashboard.model;

public class RiskModel {
	
	private String Program;
	private int StatustrackingandreportingRigor;
	private int ProjectComplexity;

	public int getStatustrackingandreportingRigor() {
		return StatustrackingandreportingRigor;
	}

	public void setStatustrackingandreportingRigor(int statustrackingandreportingRigor) {
		StatustrackingandreportingRigor = statustrackingandreportingRigor;
	}

	public int getProjectComplexity() {
		return ProjectComplexity;
	}

	public void setProjectComplexity(int projectComplexity) {
		ProjectComplexity = projectComplexity;
	}

	public String getProgram() {
		return Program;
	}

	public void setProgram(String program) {
		Program = program;
	}

	

}
