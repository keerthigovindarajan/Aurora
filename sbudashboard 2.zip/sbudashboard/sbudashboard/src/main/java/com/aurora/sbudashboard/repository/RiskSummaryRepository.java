package com.aurora.sbudashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.aurora.sbudashboard.dto.RiskSummaryDTO;
import com.aurora.sbudashboard.model.ProgramMaster;

@Repository
public interface RiskSummaryRepository extends JpaRepository<ProgramMaster, Integer> {

	@Query(value = "SELECT\r\n" + 
			"    pm.program_name As Program,\r\n" + 
			"    rcm.Risk_Type As Category,\r\n" + 
			"    count(Risk_Type) As Risk\r\n" + 
			"FROM\r\n" + 
			"    aurorademo_2.program_master pm\r\n" + 
			"        INNER JOIN\r\n" + 
			"    aurorademo_2.project_master p ON p.Aurora_Program_Seq_fk = pm.Aurora_Program_Seq\r\n" + 
			"        INNER JOIN\r\n" + 
			"    aurorademo_2.Risk_Log rl\r\n" + 
			"		INNER JOIN\r\n" + 
			"	aurorademo_2.rag_status rs on rs.Aurora_RAG_Status_Seq = rl.Aurora_RAG_Status_Seq_fk\r\n" + 
			"		INNER JOIN\r\n" + 
			"	aurorademo_2.risk_log_indicator rli on rli.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq\r\n" + 
			"		INNER JOIN\r\n" + 
			"	aurorademo_2.risk_indicator_master rim on rim.Aurora_Risk_Indicator_Seq = rli.Aurora_Risk_Indicator_Seq_pk_fk\r\n" + 
			"        INNER JOIN\r\n" + 
			"    aurorademo_2.Risk_Category_Master rcm ON rim.Aurora_Risk_Category_Seq_fk = rcm.Aurora_Risk_Category_Seq\r\n" + 
			"WHERE\r\n" + 
			"	rl.Aurora_Project_Seq_fk = p.Aurora_Project_Seq\r\n" + 
			"	&& p.Aurora_Program_Seq_fk = pm.Aurora_Program_Seq\r\n" + 
			"	&& rim.Aurora_Risk_Category_Seq_fk = rcm.Aurora_Risk_Category_Seq\r\n" + 
			"group by Program_Name,risk_type order by Program_Name desc;", nativeQuery = true)
	List<RiskSummaryDTO> getRiskSummaryDetails();

}
