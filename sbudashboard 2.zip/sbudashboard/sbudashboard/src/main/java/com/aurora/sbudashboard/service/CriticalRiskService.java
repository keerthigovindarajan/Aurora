//package com.aurora.sbudashboard.service;
//
//import java.util.List;
//
//import javax.persistence.EntityManager;
//import javax.persistence.EntityManagerFactory;
//import javax.persistence.Query;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import com.aurora.sbudashboard.dto.CriticalRisksDTO;
//
//@Service
//public class CriticalRiskService implements CriticalRisksDTO {
//
//	
//
//}
