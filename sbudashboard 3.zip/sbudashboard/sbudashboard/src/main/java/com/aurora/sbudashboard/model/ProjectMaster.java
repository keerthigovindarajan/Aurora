package com.aurora.sbudashboard.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "project_master")
public class ProjectMaster {
	
	

	@Id
	@Column(name = "Aurora_Program_Seq",columnDefinition = "int",nullable = false)
	private int auroraProgramSeq;

	
	@Column(name = "Velocity_ProjectCode",columnDefinition = "int",nullable = false)
	private int velocityProjectCode;
	
	@Column(name = "Project_Name",columnDefinition = "varchar(100)",nullable = false)
	private String projectName;
	
	@Column(name = "Aurora_Segment_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraSegmentSeqfk;
	
	@Column(name = "Project_Status",columnDefinition = "varchar(10)",nullable = false)
	private String projectStatus;
	
	@Column(name = "Resources_Currently_Allocated",columnDefinition = "char(1)",nullable = false)
	private char resourcesCurrentlyAllocated;
	
	@Column(name = "Velocity_Start_Date",columnDefinition = "date",nullable = false)
	private Date velocityStartDate;
	
	@Column(name = "Velocity_End_Date",columnDefinition = "date",nullable = false)
	private Date velocityEndDate;
	
	@Column(name = "Virtusa_Segment_DeliveryHead",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaSegmentDeliveryHead;
	
	@Column(name = "Virtusa_DD_Name",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaDDName;
	
	@Column(name = "Virtusa_DD_EmailId",columnDefinition = "varchar(100)",nullable = true)
	private String virtusaDDEmailId;
	
	@Column(name = "Virtusa_PD_Name",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaPDName;
	
	@Column(name = "Virtusa_PD_EmailId",columnDefinition = "varchar(100)",nullable = true)
	private String virtusaPDEmailId;
	
	@Column(name = "Virtusa_PM_Name",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaPMName;
	
	@Column(name = "Virtusa_PM_EmailId",columnDefinition = "varchar(100)",nullable = true)
	private String virtusaPMEmailId;
	
	@Column(name = "IT_Cluster",columnDefinition = "varchar(5)",nullable = true)
	private String itCluster;
	
	@Column(name = "Aurora_ServiceType_V_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraServiceTypeVSeqfk;
	
	@Column(name = "Aurora_Delivery_From_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraDeliveryFromSeqfk;
	
	@Column(name = "Pricing_Construct_Code_fk",columnDefinition = "varchar(10)",nullable = false)
	private String pricingConstructCodeFk;
	
	@Column(name = "Total_HC",columnDefinition = "int",nullable = false)
	private int totalHc;
	
	@Column(name = "HC_On",columnDefinition = "int",nullable = false)
	private int hcOn;
	
	@Column(name = "HC_Off",columnDefinition = "int",nullable = false)
	private int hcOff;
	
	@Column(name = "Recovery_Time_Objective",columnDefinition = "varchar(45)",nullable = true)
	private String recoveryTimeObjective;
	
	@Column(name = "Aurora_Program_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraProgramSeqfk;
	
	@Column(name = "Aurora_SOW_Seq_fk",columnDefinition = "varchar(15)")
	private String auroraSOWSeqfk;
	
	@Column(name = "Engagement_Plan_Applicability",columnDefinition = "varchar(30)",nullable = true)
	private String engagementPlanApplicability;
	
	@Column(name = "Engagement_Plan_Exemption_Reason",columnDefinition = "varchar(100)",nullable = true)
	private String engagementPlanExemptionReason;
	
	@Column(name = "SLA_Applicability",columnDefinition = "char(1)",nullable = true)
	private char slaApplicability;
	
	@Column(name = "KPI_Applicability",columnDefinition = "char(1)",nullable = true)
	private char kpiApplicability;
	
	@Column(name = "Key_Personnel_Including_PM",columnDefinition = "int",nullable = true)
	private int keyPersonnelIncludingPM;
	
	@Column(name = "Project_Life_Cycle",columnDefinition = "varchar(45)",nullable = true)
	private String projectLifeCycle;
	
	@Column(name = "Project_Applicability_Secure_SDLC",columnDefinition = "char(1)",nullable = true)
	private char projectApplicabilitySecureSDLC;
	
	@Column(name = "Project_Mobile_Development_Component",columnDefinition = "char(1)",nullable = true)
	private char projectMobileDevelopmentComponent;
	
	@Column(name = "Release_Notes_Applicability",columnDefinition = "varchar(45)",nullable = true)
	private String releaseNotesApplicability;
	
	@Column(name = "Self_Assessment_Applicability",columnDefinition = "varchar(45)",nullable = true)
	private String selfAssessmentApplicability;
	
	@Column(name = "Governance_Report_Applicability",columnDefinition = "varchar(45)",nullable = true)
	private String governanceReportApplicability;
	
	@Column(name = "Governance_Report_Frequency",columnDefinition = "varchar(45)",nullable = true)
	private String governanceReportFrequency;
	
	@Column(name = "GDPR",columnDefinition = "varchar(45)",nullable = true)
	private String gdpr;
	
	@Column(name = "Remarks",columnDefinition = "varchar(100)",nullable = true)
	private String remarks;
	
	@Column(name = "Highest_Confidentiality",columnDefinition = "varchar(20)",nullable = true)
	private String highestConfidentiality;
	
	@Column(name = "Created_Date",nullable = false)
	private Date createdDate;
	
	@Column(name = "Created_By",columnDefinition = "varchar(100)",nullable = true)
	private String createdBy;
	
	@Column(name = "Modified_Date",nullable = true)
	private Date modifiedDate;
	
	@Column(name = "Modified_By",columnDefinition = "varchar(100)",nullable = true)
	private String modifiedBy;
	
	@ManyToOne
    @JoinColumn(name ="Aurora_Program_Seq_fk",insertable = false, updatable = false)
    private ProgramMaster programMaster;

	@ManyToOne
    @JoinColumn(name ="Aurora_Segment_Seq_fk",insertable = false, updatable = false)
    private Segment segment;

	public int getVelocityProjectCode() {
		return velocityProjectCode;
	}
	
	public void setVelocityProjectCode(int velocityProjectCode) {
		this.velocityProjectCode = velocityProjectCode;
	}

	public String getProjectName() {
		return projectName;
	}
	
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
	public String getProjectStatus() {
		return projectStatus;
	}


	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}

	public char getResourcesCurrentlyAllocated() {
		return resourcesCurrentlyAllocated;
	}

	public void setResourcesCurrentlyAllocated(char resourcesCurrentlyAllocated) {
		this.resourcesCurrentlyAllocated = resourcesCurrentlyAllocated;
	}

	public Date getVelocityStartDate() {
		return velocityStartDate;
	}

	public void setVelocityStartDate(Date velocityStartDate) {
		this.velocityStartDate = velocityStartDate;
	}

	public Date getVelocityEndDate() {
		return velocityEndDate;
	}

	public void setVelocityEndDate(Date velocityEndDate) {
		this.velocityEndDate = velocityEndDate;
	}

	public String getVirtusaSegmentDeliveryHead() {
		return virtusaSegmentDeliveryHead;
	}

	public void setVirtusaSegmentDeliveryHead(String virtusaSegmentDeliveryHead) {
		this.virtusaSegmentDeliveryHead = virtusaSegmentDeliveryHead;
	}

	public String getVirtusaDDName() {
		return virtusaDDName;
	}

	public int getAuroraProgramSeq() {
		return auroraProgramSeq;
	}

	public void setAuroraProgramSeq(int auroraProgramSeq) {
		this.auroraProgramSeq = auroraProgramSeq;
	}

	public int getAuroraSegmentSeqfk() {
		return auroraSegmentSeqfk;
	}

	public void setAuroraSegmentSeqfk(int auroraSegmentSeqfk) {
		this.auroraSegmentSeqfk = auroraSegmentSeqfk;
	}

	public int getAuroraServiceTypeVSeqfk() {
		return auroraServiceTypeVSeqfk;
	}

	public void setAuroraServiceTypeVSeqfk(int auroraServiceTypeVSeqfk) {
		this.auroraServiceTypeVSeqfk = auroraServiceTypeVSeqfk;
	}

	public int getAuroraDeliveryFromSeqfk() {
		return auroraDeliveryFromSeqfk;
	}

	public void setAuroraDeliveryFromSeqfk(int auroraDeliveryFromSeqfk) {
		this.auroraDeliveryFromSeqfk = auroraDeliveryFromSeqfk;
	}

	public int getAuroraProgramSeqfk() {
		return auroraProgramSeqfk;
	}

	public void setAuroraProgramSeqfk(int auroraProgramSeqfk) {
		this.auroraProgramSeqfk = auroraProgramSeqfk;
	}

	public String getAuroraSOWSeqfk() {
		return auroraSOWSeqfk;
	}

	public void setAuroraSOWSeqfk(String auroraSOWSeqfk) {
		this.auroraSOWSeqfk = auroraSOWSeqfk;
	}

	public char getKpiApplicability() {
		return kpiApplicability;
	}

	public void setKpiApplicability(char kpiApplicability) {
		this.kpiApplicability = kpiApplicability;
	}

	public int getKeyPersonnelIncludingPM() {
		return keyPersonnelIncludingPM;
	}

	public void setKeyPersonnelIncludingPM(int keyPersonnelIncludingPM) {
		this.keyPersonnelIncludingPM = keyPersonnelIncludingPM;
	}

	public String getProjectLifeCycle() {
		return projectLifeCycle;
	}

	public void setProjectLifeCycle(String projectLifeCycle) {
		this.projectLifeCycle = projectLifeCycle;
	}

	public char getProjectApplicabilitySecureSDLC() {
		return projectApplicabilitySecureSDLC;
	}

	public void setProjectApplicabilitySecureSDLC(char projectApplicabilitySecureSDLC) {
		this.projectApplicabilitySecureSDLC = projectApplicabilitySecureSDLC;
	}

	public char getProjectMobileDevelopmentComponent() {
		return projectMobileDevelopmentComponent;
	}

	public void setProjectMobileDevelopmentComponent(char projectMobileDevelopmentComponent) {
		this.projectMobileDevelopmentComponent = projectMobileDevelopmentComponent;
	}

	public String getReleaseNotesApplicability() {
		return releaseNotesApplicability;
	}

	public void setReleaseNotesApplicability(String releaseNotesApplicability) {
		this.releaseNotesApplicability = releaseNotesApplicability;
	}

	public String getSelfAssessmentApplicability() {
		return selfAssessmentApplicability;
	}

	public void setSelfAssessmentApplicability(String selfAssessmentApplicability) {
		this.selfAssessmentApplicability = selfAssessmentApplicability;
	}

	public String getGovernanceReportApplicability() {
		return governanceReportApplicability;
	}

	public void setGovernanceReportApplicability(String governanceReportApplicability) {
		this.governanceReportApplicability = governanceReportApplicability;
	}

	public String getGovernanceReportFrequency() {
		return governanceReportFrequency;
	}

	public void setGovernanceReportFrequency(String governanceReportFrequency) {
		this.governanceReportFrequency = governanceReportFrequency;
	}

	public String getGdpr() {
		return gdpr;
	}

	public void setGdpr(String gDPR) {
		this.gdpr = gDPR;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getHighestConfidentiality() {
		return highestConfidentiality;
	}

	public void setHighestConfidentiality(String highestConfidentiality) {
		this.highestConfidentiality = highestConfidentiality;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public ProgramMaster getProgramMaster() {
		return programMaster;
	}

	public void setProgramMaster(ProgramMaster programMaster) {
		this.programMaster = programMaster;
	}

	public Segment getSegment() {
		return segment;
	}

	public void setSegment(Segment segment) {
		this.segment = segment;
	}

	public void setVirtusaDDName(String virtusaDDName) {
		this.virtusaDDName = virtusaDDName;
	}

	public String getVirtusaDDEmailId() {
		return virtusaDDEmailId;
	}

	public void setVirtusaDDEmailId(String virtusaDDEmailId) {
		this.virtusaDDEmailId = virtusaDDEmailId;
	}

	public String getVirtusaPDName() {
		return virtusaPDName;
	}

	public void setVirtusaPDName(String virtusaPDName) {
		this.virtusaPDName = virtusaPDName;
	}

	public String getVirtusaPDEmailId() {
		return virtusaPDEmailId;
	}



	public void setVirtusaPDEmailId(String virtusaPDEmailId) {
		this.virtusaPDEmailId = virtusaPDEmailId;
	}



	public String getVirtusaPMName() {
		return virtusaPMName;
	}



	public void setVirtusaPMName(String virtusaPMName) {
		this.virtusaPMName = virtusaPMName;
	}



	public String getVirtusaPMEmailId() {
		return virtusaPMEmailId;
	}



	public void setVirtusaPMEmailId(String virtusaPMEmailId) {
		this.virtusaPMEmailId = virtusaPMEmailId;
	}



	public String getItCluster() {
		return itCluster;
	}



	public void setItCluster(String itCluster) {
		this.itCluster = itCluster;
	}


	public String getPricingConstructCodeFk() {
		return pricingConstructCodeFk;
	}

	public void setPricingConstructCodeFk(String pricingConstructCodeFk) {
		this.pricingConstructCodeFk = pricingConstructCodeFk;
	}

	public int getTotalHc() {
		return totalHc;
	}

	public void setTotalHc(int totalHc) {
		this.totalHc = totalHc;
	}

	public int getHcOn() {
		return hcOn;
	}

	public void setHcOn(int hcOn) {
		this.hcOn = hcOn;
	}

	public int getHcOff() {
		return hcOff;
	}
	public void setHcOff(int hcOff) {
		this.hcOff = hcOff;
	}

	public String getRecoveryTimeObjective() {
		return recoveryTimeObjective;
	}

	public void setRecoveryTimeObjective(String recoveryTimeObjective) {
		this.recoveryTimeObjective = recoveryTimeObjective;
	}


	public String getEngagementPlanApplicability() {
		return engagementPlanApplicability;
	}



	public void setEngagementPlanApplicability(String engagementPlanApplicability) {
		this.engagementPlanApplicability = engagementPlanApplicability;
	}



	public String getEngagementPlanExemptionReason() {
		return engagementPlanExemptionReason;
	}



	public void setEngagementPlanExemptionReason(String engagementPlanExemptionReason) {
		this.engagementPlanExemptionReason = engagementPlanExemptionReason;
	}



	public char getSlaApplicability() {
		return slaApplicability;
	}

	public void setSlaApplicability(char slaApplicability) {
		this.slaApplicability = slaApplicability;
	}



	

}
