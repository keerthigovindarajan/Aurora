package com.aurora.sbudashboard.config;

public final class Constants {

	public static final String PROJECT_COMPLEXITY = "Project Complexity";
	public static final String STATUS_TRACKING_AND_REPORTING_RIGOR = "Status tracking & reporting Rigor";
	public static final String RESOURCE_FULLFILLMENT_OR_STABILITY_OR_ATTRITION = "Resource Fullfillment/Stability/Attrition";
	public static final String TEAM_COMPETENCY_AND_SKILL = "Team Competency and Skill";
	public static final String EFFORT_ESTIMATES = "Effort Estimates";
	public static final String SCHEDULE_ESTIMATES = "Schedule Estimates";
	public static final String REQUIREMENTS_STABILITY_OR_CLARITY = "Requirements Stability / Clarity";
	public static final String MILESTONE_ACHIEVEMENT = "Milestone Achievement";
	public static final String CODE_QUALITY_AND_HIGH_DEFECTS_DENSITY = "Code Quality & High Defects Density";
	public static final String PRODUCTIVITY_BLUE_OPTIMA = "Productivity (Blue Optima)";
	public static final String PRODUCTIVITY_DTA = "Productivity (DTA)";
	public static final String CUSTOMER_SLA = "Customer SLA";
	public static final String PROJECT_MANAGEMENT_RISK = "Project Management Risk";
	public static final String TEAM_ORGANIZATION_AND_STRUCTURE = "Team Organization and Structure";
	public static final String SUBCONTRACTING_AND_VENDOR_DELIVERABLES = "SubContracting and Vendor Deliverables";
	public static final String CUSTOMER_COMMITMENT = "Customer Commitment";
	public static final String CUSTOMER_PROCESS = "Customer Process";

	private Constants() {

	}

}
