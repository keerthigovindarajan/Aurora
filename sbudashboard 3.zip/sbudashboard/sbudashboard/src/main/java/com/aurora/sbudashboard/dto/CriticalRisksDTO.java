package com.aurora.sbudashboard.dto;

public interface  CriticalRisksDTO {
	
	
	 String getSegment();
	 String getProgram();
	 String getProject();
	 Integer getRiskID();
	 String getRiskCategory();
	 String getRiskIdentifiedThrough();
	 String getRiskIdentifiedBy(); 
	 String getImpact(); 
	 String getRAG(); 
	 String getOpensince();
	 
	 
	
}
