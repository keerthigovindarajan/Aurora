package com.aurora.sbudashboard.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.aurora.sbudashboard.config.Constants;
import com.aurora.sbudashboard.controller.DashboardController;
import com.aurora.sbudashboard.dto.RiskSummaryDTO;
import com.aurora.sbudashboard.dtoimpl.RiskSummaryDTOImpl;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.RiskSummaryRepository;

@RunWith(SpringRunner.class)
public class RiskSummaryServiceTest {

	
	@Mock
	public RiskSummaryDTOImpl riskSummaryDTO;
	@InjectMocks
	private RiskSummaryService service;
	@Mock
	private RiskSummaryRepository repository;

	List<RiskSummaryDTO> li1;
	RiskSummaryDTOImpl impl;
	List<RiskModel> li;
	RiskModel ri;
	Constants consts;


	@Before
	public void setup() {
		consts = new Constants();
		service.setRepository(repository);
		li1 = new ArrayList<>();
		impl = new RiskSummaryDTOImpl();
		impl.setCategory("Project Complexity");
		impl.setProgram("stars");
		impl.setRisk(0);
		li1.add(impl);
		li = new ArrayList<>();
		ri = new RiskModel();
		ri = new RiskModel();
		ri.setProgram("program");
		li.add(ri);
	}



	@Test
	public void getRiskSummaryTestCategory1() {
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PROJECT_COMPLEXITY);
		impl.setRisk(2);
		li1.add(impl);
		ri.setProjectComplexity(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory2() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.STATUS_TRACKING_AND_REPORTING_RIGOR);
		impl.setRisk(0);
		li1.add(impl);
		ri.setStatustrackingandreportingRigor(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory3() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.RESOURCE_FULLFILLMENT_OR_STABILITY_OR_ATTRITION);
		impl.setRisk(0);
		li1.add(impl);
		ri.setStatustrackingandreportingRigor(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory4() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.TEAM_COMPETENCY_AND_SKILL);
		impl.setRisk(0);
		li1.add(impl);
		ri.setTeamCompetencyandSkill(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory5() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.EFFORT_ESTIMATES);
		impl.setRisk(0);
		li1.add(impl);
		ri.setEffortEstimates(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory6() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.SCHEDULE_ESTIMATES);
		impl.setRisk(0);
		li1.add(impl);
		ri.setScheduleEstimates(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory7() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.REQUIREMENTS_STABILITY_OR_CLARITY);
		impl.setRisk(0);
		li1.add(impl);
		ri.setRequirementsStabilityorClarity(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory8() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.MILESTONE_ACHIEVEMENT);
		impl.setRisk(0);
		li1.add(impl);
		ri.setMilestoneAchievement(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory9() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CODE_QUALITY_AND_HIGH_DEFECTS_DENSITY);
		impl.setRisk(0);
		li1.add(impl);
		ri.setCodeQualityandHighDefectsDensity(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory10() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PRODUCTIVITY_BLUE_OPTIMA);
		impl.setRisk(0);
		li1.add(impl);
		ri.setProductivityBlueOptima(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory11() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PRODUCTIVITY_DTA);
		impl.setRisk(0);
		li1.add(impl);
		ri.setProductivityDta(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory12() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CUSTOMER_SLA);
		impl.setRisk(0);
		li1.add(impl);
		ri.setCustomerSLA(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory13() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PROJECT_MANAGEMENT_RISK);
		impl.setRisk(0);
		li1.add(impl);
		ri.setProjectManagementRisk(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory14() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.TEAM_ORGANIZATION_AND_STRUCTURE);
		impl.setRisk(0);
		li1.add(impl);
		ri.setTeamOrganizationandStructure(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory15() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.SUBCONTRACTING_AND_VENDOR_DELIVERABLES);
		impl.setRisk(0);
		li1.add(impl);
		ri.setSubContractingandVendorDeliverables(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory16() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CUSTOMER_COMMITMENT);
		impl.setRisk(0);
		li1.add(impl);
		ri.setCustomerCommitment(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory17() {
		Constants consts = new Constants();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CUSTOMER_PROCESS);
		impl.setRisk(0);
		li1.add(impl);
		ri.setCustomerProcess(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}
		


}