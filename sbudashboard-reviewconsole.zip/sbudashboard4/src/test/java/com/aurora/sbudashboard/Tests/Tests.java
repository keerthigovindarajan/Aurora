package com.aurora.sbudashboard.Tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.aurora.sbudashboard.controller.DashboardControllerTest;
import com.aurora.sbudashboard.model.ProgramMasterTest;
import com.aurora.sbudashboard.model.RiskModelTest;
import com.aurora.sbudashboard.service.RiskSummaryServiceTest;
import com.aurora.sbudashboard.service.RiskSummaryServiceTest1;
import com.aurora.sbudashboard.service.RiskSummaryServiceTest2;

@RunWith(Suite.class)
@SuiteClasses({DashboardControllerTest.class,RiskSummaryServiceTest.class,RiskSummaryServiceTest1.class,RiskSummaryServiceTest2.class,ProgramMasterTest.class,RiskModelTest.class,
	})
public class Tests {

}



