package com.aurora.sbudashboard.controller;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.CriticalRisksRepository;
import com.aurora.sbudashboard.service.RiskSummaryService;
@RunWith(SpringRunner.class)
//@WebMvcTest(controllers = DashboardController.class)
@SpringBootTest
@AutoConfigureMockMvc
public class DashboardControllerTest {

	
	public CriticalRisksDTO criticalRisksDTO;

	@Autowired
	private MockMvc mockMvc;
	
//	@InjectMocks
//	DashboardController controller;
	@MockBean
	private CriticalRisksRepository repo;
	@MockBean
	private RiskSummaryService service;
//	@Mock
//	private RestTemplate restTemplate;
	
	List<RiskModel> mockli ;

	@Test
	public void openRisksDetailsTest() throws Exception {

		List<CriticalRisksDTO> li = new ArrayList<>();
		li.add(criticalRisksDTO);
		Mockito.when(repo.getCriticalRisksDetails()).thenReturn(li);
		RequestBuilder req = MockMvcRequestBuilders.get("/api/citi-portal/criticalRisks").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(req).andReturn();
		MockHttpServletResponse res = result.getResponse();
		System.out.println(res.getContentAsString());
		assertEquals(HttpStatus.OK.value(), res.getStatus());		
	}

	@Test
	public void riskSummaryTest() throws Exception {
		HttpHeaders header = new HttpHeaders();
		header.setContentType(MediaType.APPLICATION_JSON);
		RiskModel riskmodel = new RiskModel();
		
		riskmodel.setCustomerSLA(2);
		List<RiskModel> li = new ArrayList<>();
		li.add(riskmodel);

		Mockito.when(service.getRiskSummary()).thenReturn(li);
		RequestBuilder req = MockMvcRequestBuilders.get("/api/citi-portal/riskSummary").accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(req).andReturn();
		MockHttpServletResponse res = result.getResponse();
		System.out.println(res.getContentAsString());
		assertEquals(HttpStatus.OK.value(), res.getStatus());

	}
}