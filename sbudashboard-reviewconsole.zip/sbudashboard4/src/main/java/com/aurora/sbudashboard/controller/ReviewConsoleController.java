package com.aurora.sbudashboard.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aurora.sbudashboard.dto.ProgramDetailDTO;
import com.aurora.sbudashboard.dto.RiskLogDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.service.ReviewConsoleService;

import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/citi-portal")
@Api(value = "Dashboard", description = "Aurora Dashboard")
public class ReviewConsoleController {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ReviewConsoleService service;
	
	
	@ApiResponse
	@Operation(summary = "Get the details about critical open risks and Risk summary", description = "", responses = {
			@ApiResponse(content = @Content(schema = @Schema(implementation = RiskModel.class), mediaType = MediaType.APPLICATION_JSON_VALUE), description = "", responseCode = "200") })

	@GetMapping("/earlyWarningHotspots")
	public ResponseEntity<List<ProgramDetailDTO>> earlyWarning(@RequestParam("programName") String program) {
		log.info("Request has been made to get the Details of Program");
		List<ProgramDetailDTO> dto = service.earlyWarningDetails(program);
		return new ResponseEntity<List<ProgramDetailDTO>>(dto, HttpStatus.OK);
	}
	@GetMapping("/riskLog")
	public ResponseEntity<List<RiskLogDTO>> riskLog(@RequestParam("programName") String program) {

		log.info("Request has been made to get the List of Critical Open Risks");
		List<RiskLogDTO> dto = service.riskLogDetails(program);
		return new ResponseEntity<List<RiskLogDTO>>(dto, HttpStatus.OK);

	}
}
