package com.aurora.sbudashboard.dtoimpl;

import com.aurora.sbudashboard.dto.RiskSummaryDTO;

public class RiskSummaryDTOImpl implements RiskSummaryDTO{
	String program;
	String category;
	Integer risk;
	@Override
	public String getProgram() {
		return program;
	}

	@Override
	public String getCategory() {
		return category;
	}

	@Override
	public Integer getRisk() {
		return risk;
	}

	@Override
	public void setProgram(String program) {
		this.program = program;
		
	}

	@Override
	public void setCategory(String category) {
		this.category = category;
		
	}

	@Override
	public void setRisk(int risk) {
		this.risk = risk;
	}

}
