package com.aurora.sbudashboard.model;

public class RiskModel {


	private String program;
	private int statustrackingandreportingRigor;
	private int projectComplexity;
	private int resourceFullfillmentorStabilityorAttrition;
	private int teamCompetencyandSkill;
	private int effortEstimates;
	private int scheduleEstimates;
	private int requirementsStabilityorClarity;
	private int milestoneAchievement;
	private int codeQualityandHighDefectsDensity;
	private int productivityBlueOptima;
	private int productivityDta;
	private int customerSLA;
	private int projectManagementRisk;
	private int teamOrganizationandStructure;
	private int subContractingandVendorDeliverables;
	private int customerCommitment;
	private int customerProcess;
	public String getProgram() {
		return program;
	}
	public void setProgram(String program) {
		this.program = program;
	}
	public int getStatustrackingandreportingRigor() {
		return statustrackingandreportingRigor;
	}
	public void setStatustrackingandreportingRigor(int statustrackingandreportingRigor) {
		this.statustrackingandreportingRigor = statustrackingandreportingRigor;
	}
	public int getProjectComplexity() {
		return projectComplexity;
	}
	public void setProjectComplexity(int projectComplexity) {
		this.projectComplexity = projectComplexity;
	}
	public int getResourceFullfillmentorStabilityorAttrition() {
		return resourceFullfillmentorStabilityorAttrition;
	}
	public void setResourceFullfillmentorStabilityorAttrition(int resourceFullfillmentorStabilityorAttrition) {
		this.resourceFullfillmentorStabilityorAttrition = resourceFullfillmentorStabilityorAttrition;
	}
	public int getTeamCompetencyandSkill() {
		return teamCompetencyandSkill;
	}
	public void setTeamCompetencyandSkill(int teamCompetencyandSkill) {
		this.teamCompetencyandSkill = teamCompetencyandSkill;
	}
	public int getEffortEstimates() {
		return effortEstimates;
	}
	public void setEffortEstimates(int effortEstimates) {
		this.effortEstimates = effortEstimates;
	}
	public int getScheduleEstimates() {
		return scheduleEstimates;
	}
	public void setScheduleEstimates(int scheduleEstimates) {
		this.scheduleEstimates = scheduleEstimates;
	}
	public int getRequirementsStabilityorClarity() {
		return requirementsStabilityorClarity;
	}
	public void setRequirementsStabilityorClarity(int requirementsStabilityorClarity) {
		this.requirementsStabilityorClarity = requirementsStabilityorClarity;
	}
	public int getMilestoneAchievement() {
		return milestoneAchievement;
	}
	public void setMilestoneAchievement(int milestoneAchievement) {
		this.milestoneAchievement = milestoneAchievement;
	}
	public int getCodeQualityandHighDefectsDensity() {
		return codeQualityandHighDefectsDensity;
	}
	public void setCodeQualityandHighDefectsDensity(int codeQualityandHighDefectsDensity) {
		this.codeQualityandHighDefectsDensity = codeQualityandHighDefectsDensity;
	}
	public int getProductivityBlueOptima() {
		return productivityBlueOptima;
	}
	public void setProductivityBlueOptima(int productivityBlueOptima) {
		this.productivityBlueOptima = productivityBlueOptima;
	}
	public int getProductivityDta() {
		return productivityDta;
	}
	public void setProductivityDta(int productivityDta) {
		this.productivityDta = productivityDta;
	}
	public int getCustomerSLA() {
		return customerSLA;
	}
	public void setCustomerSLA(int customerSLA) {
		this.customerSLA = customerSLA;
	}
	public int getProjectManagementRisk() {
		return projectManagementRisk;
	}
	public void setProjectManagementRisk(int projectManagementRisk) {
		this.projectManagementRisk = projectManagementRisk;
	}
	public int getTeamOrganizationandStructure() {
		return teamOrganizationandStructure;
	}
	public void setTeamOrganizationandStructure(int teamOrganizationandStructure) {
		this.teamOrganizationandStructure = teamOrganizationandStructure;
	}
	public int getSubContractingandVendorDeliverables() {
		return subContractingandVendorDeliverables;
	}
	public void setSubContractingandVendorDeliverables(int subContractingandVendorDeliverables) {
		this.subContractingandVendorDeliverables = subContractingandVendorDeliverables;
	}
	public int getCustomerCommitment() {
		return customerCommitment;
	}
	public void setCustomerCommitment(int customerCommitment) {
		this.customerCommitment = customerCommitment;
	}
	public int getCustomerProcess() {
		return customerProcess;
	}
	public void setCustomerProcess(int customerProcess) {
		this.customerProcess = customerProcess;
	}
	

}