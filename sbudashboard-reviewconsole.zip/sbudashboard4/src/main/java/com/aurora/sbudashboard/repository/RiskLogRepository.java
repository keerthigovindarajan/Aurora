package com.aurora.sbudashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import com.aurora.sbudashboard.dto.RiskLogDTO;
import com.aurora.sbudashboard.model.ProgramMaster;

@Repository
public interface RiskLogRepository extends JpaRepository<ProgramMaster, Integer> {
	@Query(value = "\r\n" + 
			"SELECT \r\n" + 
			"    Project_Name AS Project,\r\n" + 
			"    Risk_type AS 'RiskCategory',\r\n" + 
			"    Risk_Identified As 'RiskIdentified',\r\n" + 
			"    Risk_Indicator_Source AS 'RiskIdentifiedBy',\r\n" + 
			"    Created_By AS 'RiskInitiator',\r\n" + 
			"    DATE_FORMAT(Created_Date, '%d-%b-%y') AS 'RiskIdentifiedOn',\r\n" + 
			"    Impact,\r\n" + 
			"    Risk_Description AS 'RiskDescription',\r\n" + 
			"    Remediation,\r\n" + 
			"    Risk_Status AS Status,\r\n" + 
			"    Chorus_Alert_Id AS 'ChorusAlertID',\r\n" + 
			"    DxT_Alert AS 'DxTAlert',\r\n" + 
			"    rag_status_value AS RAG\r\n" + 
			"FROM\r\n" + 
			"    (SELECT \r\n" + 
			"        Program_Name,\r\n" + 
			"            Aurora_Risk_Seq,\r\n" + 
			"            Project_Name,\r\n" + 
			"            Risk_type,\r\n" + 
			"            GROUP_CONCAT(DISTINCT Risk_Indicator SEPARATOR ',') AS Risk_Identified,\r\n" + 
			"            Risk_Indicator_Source,\r\n" + 
			"            Created_By,\r\n" + 
			"            Created_Date,\r\n" + 
			"			GROUP_CONCAT(DISTINCT Impact_Type SEPARATOR ',') AS Impact,\r\n" + 
			"            Risk_Description,\r\n" + 
			"            Remediation,\r\n" + 
			"            Risk_Status,\r\n" + 
			"            Chorus_Alert_Id,\r\n" + 
			"            DxT_Alert,\r\n" + 
			"            rag_status_value,\r\n" + 
			"			Severity_Level\r\n" + 
			"\r\n" + 
			"    FROM\r\n" + 
			"        (SELECT \r\n" + 
			"        pmr.Program_Name,\r\n" + 
			"            pm.Project_Name,\r\n" + 
			"            rl.Aurora_Risk_Seq,\r\n" + 
			"            cm.risk_type,\r\n" + 
			"            rimm.Risk_Indicator,\r\n" + 
			"            rl.Risk_Indicator_Source,\r\n" + 
			"            rl.Created_By,\r\n" + 
			"            rl.Created_Date,\r\n" + 
			"            im.Impact_Type,\r\n" + 
			"            rl.Risk_Description,\r\n" + 
			"            rl.Remediation,\r\n" + 
			"            rl.Risk_Status,\r\n" + 
			"            rl.Chorus_Alert_Id,\r\n" + 
			"            rl.DxT_Alert,\r\n" + 
			"            rs.rag_status_value,\r\n" + 
			"            rs.Severity_Level\r\n" + 
			"    FROM\r\n" + 
			"        program_master pmr\r\n" + 
			"    INNER JOIN project_master pm ON pm.Aurora_Program_Seq_fk = pmr.Aurora_Program_Seq\r\n" + 
			"    INNER JOIN SEGMENT S ON S.Aurora_Segment_Seq = PM.Aurora_Segment_Seq_fk\r\n" + 
			"    INNER JOIN risk_log rl ON pm.Aurora_Project_Seq = rl.Aurora_Project_Seq_fk\r\n" + 
			"    INNER JOIN rag_status rs ON rl.Aurora_RAG_Status_Seq_fk = rs.Aurora_RAG_Status_Seq\r\n" + 
			"    INNER JOIN risk_impact ri ON ri.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq\r\n" + 
			"    INNER JOIN impact_master im ON im.Aurora_Impact_Category_Seq = ri.Aurora_Impact_Category_Seq_pk_fk\r\n" + 
			"    INNER JOIN risk_log_indicator li ON li.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq\r\n" + 
			"    INNER JOIN risk_indicator_master rim ON rim.Aurora_Risk_Indicator_Seq = li.Aurora_Risk_Indicator_Seq_pk_fk\r\n" + 
			"    INNER JOIN risk_category_master cm ON cm.Aurora_Risk_Category_Seq = rim.Aurora_Risk_Category_Seq_fk\r\n" + 
			"    INNER JOIN risk_indicator_master rimm ON rimm.Aurora_Risk_Category_Seq_fk = cm.Aurora_Risk_Category_Seq\r\n" + 
			"    WHERE\r\n" + 
			"        rl.risk_status = 'A') AS inner_query1\r\n" + 
			"    GROUP BY Aurora_Risk_Seq\r\n" + 
			"    HAVING inner_query1.Program_Name = :programName\r\n" + 
			"    ORDER BY Severity_Level DESC , Created_Date ASC) AS iq2\r\n" + 
			"ORDER BY Severity_Level DESC , Created_Date ASC;" , nativeQuery = true)
	List<RiskLogDTO> getRiskLog(@RequestParam("programName") String programName);
}
