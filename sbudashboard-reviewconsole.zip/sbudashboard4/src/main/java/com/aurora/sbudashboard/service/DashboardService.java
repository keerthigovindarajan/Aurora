package com.aurora.sbudashboard.service;

import java.util.List;

import org.hibernate.exception.JDBCConnectionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.repository.CriticalRisksRepository;
import com.aurora.sbudashboard.repository.RiskLogRepository;

@Service
public class DashboardService {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CriticalRisksRepository criticalRisksRepo;

	public List<CriticalRisksDTO> criticalRisks() {
		try {
				log.info("Request has been made to get the List of critical Risks");
				List<CriticalRisksDTO> dto = criticalRisksRepo.getCriticalRisksDetails();
				return dto;
		}catch(JDBCConnectionException exception) {
			
			throw exception;
			
		}catch(Exception ex) {
			
			throw ex;
			
		}
		}

}
