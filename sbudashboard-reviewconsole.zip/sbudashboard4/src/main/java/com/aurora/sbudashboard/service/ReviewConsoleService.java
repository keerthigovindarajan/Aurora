package com.aurora.sbudashboard.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurora.sbudashboard.dto.ProgramDetailDTO;
import com.aurora.sbudashboard.dto.RiskLogDTO;
import com.aurora.sbudashboard.repository.ProgramDetailRepository;
import com.aurora.sbudashboard.repository.RiskLogRepository;

@Service
public class ReviewConsoleService {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private ProgramDetailRepository programRepo;

	@Autowired
	private RiskLogRepository riskLogRepo;

	public List<ProgramDetailDTO> earlyWarningDetails(String programName) {
		log.info("Request has been made to get the List of early warning program details");
		return programRepo.getProgramDetails(programName);
	}
	
	public List<RiskLogDTO> riskLogDetails(String programName) {
		log.info("Request has been made to get the List of risk log for given program");
		return riskLogRepo.getRiskLog(programName);
	}

}
