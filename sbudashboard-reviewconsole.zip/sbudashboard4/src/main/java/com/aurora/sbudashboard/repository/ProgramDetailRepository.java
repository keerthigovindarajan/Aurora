package com.aurora.sbudashboard.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.aurora.sbudashboard.dto.ProgramDetailDTO;
import com.aurora.sbudashboard.model.ProgramMaster;

@Repository
public interface ProgramDetailRepository extends JpaRepository<ProgramMaster, Integer>{

	@Query(value ="SELECT\r\n" + 
			"    pm.program_name,\r\n" + 
			"    p.project_name as Project,\r\n" + 
			"	rs.RAG_Status_Value as RAG,\r\n" + 
			"    count(rcm.Risk_Type) as Risks,\r\n" + 
			"    pli.Margin,\r\n" + 
			"    pli.Past_Due_RRs as 'PastDueRRs',\r\n" + 
			"    pli.Ageing_Of_PastDue_RRs as 'PastDueRRsAging',\r\n" + 
			"    pli.churn_attrition_count as 'AttritionTopTalentandTopTier',\r\n" + 
			"    pli.Revenue as 'UnbilledRevenue',\r\n" + 
			"    if(rl.DxT_Alert='N',0,1) as 'DxTAlerts'\r\n" + 
			"FROM\r\n" + 
			"    program_master pm\r\n" + 
			"        INNER JOIN\r\n" + 
			"    project_master p ON p.aurora_program_seq_fk = pm.aurora_program_seq\r\n" + 
			"        INNER JOIN\r\n" + 
			"    Risk_Log rl\r\n" + 
			"		INNER JOIN\r\n" + 
			"	rag_status rs on rs.aurora_RAG_Status_seq = rl.aurora_RAG_Status_seq_fk\r\n" + 
			"		INNER JOIN\r\n" + 
			"	risk_log_indicator rli on rli.aurora_Risk_seq_pk_fk = rl.aurora_risk_seq\r\n" + 
			"		INNER JOIN\r\n" + 
			"	risk_indicator_master rim on rim.aurora_Risk_Indicator_seq = rli.aurora_Risk_Indicator_seq_pk_fk\r\n" + 
			"        INNER JOIN\r\n" + 
			"    Risk_Category_Master rcm ON rim.aurora_Risk_Category_seq_fk = rcm.aurora_Risk_Category_seq\r\n" + 
			"		INNER JOIN\r\n" + 
			"	chorus_master cm ON cm.aurora_project_seq_fk = p.aurora_project_seq\r\n" + 
			"		INNER JOIN\r\n" + 
			"	project_leading_indicator pli ON pli.chorus_code_pk_fk = cm.chorus_code\r\n" + 
			"WHERE\r\n" + 
			"	rl.aurora_Project_seq_fk = p.aurora_Project_seq\r\n" + 
			"	&& p.aurora_program_seq_fk = pm.aurora_program_seq\r\n" + 
			"	&& rim.aurora_Risk_Category_seq_fk = rcm.aurora_Risk_Category_seq\r\n" + 
			"group by risk_type\r\n" + 
			"having program_name=:programName\r\n" + 
			"order by Severity_Level desc;",nativeQuery = true)
	List<ProgramDetailDTO> getProgramDetails(@RequestParam("programName") String programName);
}
