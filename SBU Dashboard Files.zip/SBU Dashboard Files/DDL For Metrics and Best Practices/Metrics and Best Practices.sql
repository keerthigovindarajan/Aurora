-- -----------------------------------------------------
-- Table Aurora.`BEST_PRACTICE_CATEGORY_MASTER`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Aurora`.`BEST_PRACTICE_CATEGORY_MASTER` ;

CREATE TABLE IF NOT EXISTS `BEST_PRACTICE_CATEGORY_MASTER`(
 Aurora_Best_Practice_Category_Seq INT NOT NULL AUTO_INCREMENT,
 Best_Practice_Category VARCHAR(45) NULL, 
 PRIMARY KEY (Aurora_Best_Practice_Category_Seq)) 
 ENGINE = InnoDB;
 
 
 
-- -----------------------------------------------------
-- Table Aurora.`BEST_PRACTICE `
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Aurora`.`BEST_PRACTICE` ;

CREATE TABLE IF NOT EXISTS `Aurora`.`BEST_PRACTICE`  (
Aurora_Project_Seq INT NOT NULL,
Aurora_Best_Practice_Category_Seq INT NOT NULL,
Best_Practice_Description VARCHAR(100) NOT NULL,
Problem_Addressed VARCHAR(100) NULL,
Solution VARCHAR(100) NULL,
Created_Date DATE NOT NULL,
Created_By VARCHAR(100) NOT NULL,
Modified_Date DATE NULL,
Modified_By VARCHAR(100) NULL,
PRIMARY KEY (Aurora_Project_Seq, Aurora_Best_Practice_Category_Seq),
INDEX fk_BEST_PRACTICE_has_PROJECT_MASTER_idx (Aurora_Project_Seq ASC),
CONSTRAINT FK1
FOREIGN KEY (Aurora_Project_Seq)
REFERENCES PROJECT_MASTER (Aurora_Project_Seq)
ON DELETE NO ACTION
ON UPDATE NO ACTION,
CONSTRAINT FK2
FOREIGN KEY (Aurora_Best_Practice_Category_Seq)
REFERENCES BEST_PRACTICE_CATEGORY_MASTER (Aurora_Best_Practice_Category_Seq)
ON DELETE NO ACTION
ON UPDATE NO ACTION)
ENGINE = InnoDB;
-- -----------------------------------------------------
-- Table Aurora.`METRICS_MASTER`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Aurora`.`METRICS_MASTER` ;

CREATE TABLE IF NOT EXISTS `metrics_master` (
    `Aurora_Metrics_Seq` INT AUTO_INCREMENT,
    `Metric_Name` VARCHAR(45) NOT NULL,
    PRIMARY KEY (Aurora_Metrics_Seq)
);

-- -----------------------------------------------------
-- Table Aurora.`PROJECT_METRICS`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Aurora`.`PROJECT_METRICS` ;


CREATE TABLE IF NOT EXISTS `Aurora`.`PROJECT_METRICS` (
    `Aurora_Project_Metric_Seq` INT AUTO_INCREMENT,
    `Aurora_Project_Seq_pk_fk` INT NOT NULL,
    `Aurora_Metrics_Seq_pk_fk` INT NOT NULL,
    `Date_or_Release_Based` VARCHAR(45) NOT NULL,
    `Captured_Date` DATE NULL,
    `Captured_Release` VARCHAR(100) NULL,
    `Metric_Value` DECIMAL(4 , 2 ) NOT NULL,
    `chart_type` VARCHAR(45) NOT NULL,
    `Created_Date` DATE NOT NULL,
    `Created_By` VARCHAR(100) NOT NULL,
    `Modified_Date` DATE NULL,
    `Modified_By` VARCHAR(100) NULL,
    PRIMARY KEY (Aurora_Project_Metric_Seq),
    CONSTRAINT `fk_PROJECT_MASTER_project_metrics` FOREIGN KEY (`Aurora_Project_Seq_pk_fk`)
        REFERENCES `project_master` (`Aurora_Project_Seq`)
        ON DELETE NO ACTION ON UPDATE NO ACTION,
    CONSTRAINT `fk_project_metrics_Metrics_Master` FOREIGN KEY (`Aurora_Metrics_Seq_pk_fk`)
        REFERENCES `metrics_master` (`Aurora_Metrics_Seq`)
        ON DELETE NO ACTION ON UPDATE NO ACTION
);