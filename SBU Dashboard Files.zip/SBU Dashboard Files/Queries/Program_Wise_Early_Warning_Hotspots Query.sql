SELECT DISTINCT
    innerquery4.Project_Name AS Project,
    RAG,
    Risks,
    Margin,
    Past_Due_RRs AS PastDueRRs,
    Ageing_Of_PastDue_RRs AS AgeingOfPastDueRRs,
    Churn_Attrition_Count AS AttritionTopTalentandTopTier,
    Revenue,
    DxT_Alert AS DxTAlerts
FROM
    (SELECT DISTINCT
			Program_Name,
            innerquery3.Project_Name,
            innerquery3.Aurora_Risk_Seq,
            innerquery3.project,
            Risks,
            innerquery3.Aurora_Project_Seq_fk,
            Aurora_RAG_Status_Seq_fk,
            RAG,
            Severity_Level,
            c.chorus_code AS chcode,
            DxT_Alert
    FROM
        (SELECT DISTINCT
			Program_Name,
            Project_Name,
            COUNT(IF(Risk_Status ='A', Aurora_Project_Seq_fk,Null)) AS Risks,
            Aurora_Risk_Seq,
            innerquery2.project,
            Aurora_Project_Seq_fk,
            Aurora_RAG_Status_Seq_fk,
            RAG,
            Severity_Level,
            COUNT(IF(DxT_Alert = 'Y'and Risk_Status ='A', DxT_Alert, Null)) AS DxT_Alert
    FROM
        (SELECT DISTINCT
        Program_Name,
            Project_Name,
            Aurora_Risk_Seq,
            Risk_Status,
            Aurora_Project_Seq_fk,
            innerquery1.Project,
            Aurora_RAG_Status_Seq_fk,
            RAG,
            Severity_Level,
            DxT_Alert
    FROM
        (SELECT DISTINCT
			pmr.Program_Name,
            pm.Project_Name,
            rl.Aurora_Risk_Seq,
            rl.Risk_Status,
            rl.Aurora_Project_Seq_fk,
            pm.Aurora_Project_Seq AS Project,
            Aurora_RAG_Status_Seq_fk,
            IF(Risk_Status ='A',rs.RAG_Status_Value,Null) as RAG,
            rs.Severity_Level,
            rl.DxT_Alert
    FROM
        project_master pm
    LEFT JOIN program_master pmr ON pmr.Aurora_Programs_Seq = pm.Aurora_Program_Seq_fk
    LEFT JOIN risk_log rl ON rl.Aurora_Project_Seq_fk = pm.Aurora_Project_Seq
    LEFT JOIN rag_status rs ON rs.Aurora_RAG_Status_Seq = rl.Aurora_RAG_Status_Seq_fk

    ORDER BY Severity_Level DESC) AS innerquery1  WHERE  innerquery1.Program_Name = 'ICG MHS -PS' 
    ORDER BY Severity_Level DESC) AS innerquery2
    GROUP BY project_name 
    ORDER BY Severity_Level DESC) AS innerquery3, chorus_master c
    INNER JOIN project_master pmm ON c.Aurora_Project_Seq_fk = Aurora_Project_Seq
    WHERE
        c.Aurora_Project_Seq_fk = Project
    ORDER BY innerquery3.Severity_Level DESC) AS innerquery4,
    chorus_master cmm
        INNER JOIN
    project_leading_indicator pli ON pli.chorus_code_pk_fk = chorus_code
WHERE
    pli.chorus_code_pk_fk = chcode
GROUP BY project_name 
ORDER BY project_name asc,innerquery4.Severity_Level DESC;
   
   
   