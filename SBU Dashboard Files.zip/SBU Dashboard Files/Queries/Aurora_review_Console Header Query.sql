SELECT 
    Segment,
    Program,
    PM
    
FROM
    (SELECT 
			s.Segment_Value AS 'Segment',
			Program_Name AS 'Program',
            pmr.Program_Manager AS 'PM'
            
    FROM
        program_master pmr
    INNER JOIN project_master p ON p.Aurora_Program_Seq_fk = pmr.Aurora_Program_Seq
    INNER JOIN segment s on s.Aurora_Segment_Seq = p.Aurora_Segment_Seq_fk
    
    WHERE
        program_name = 'ICG MHS -PS' group by program_name ) AS a;