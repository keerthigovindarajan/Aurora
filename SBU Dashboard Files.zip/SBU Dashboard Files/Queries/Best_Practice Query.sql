SELECT 
    best_practice_category,
    COUNT(Best_Practice_Category) AS count
FROM
    best_practice_category_master bpcm
        INNER JOIN
    best_practice bp ON bp.Aurora_Best_Practice_Category_Seq = bpcm.Aurora_Best_Practice_Category_Seq
GROUP BY Best_Practice_Category
ORDER BY count DESC;