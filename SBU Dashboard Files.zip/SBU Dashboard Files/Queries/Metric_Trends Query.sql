 SELECT 
    Project,
    MetricName,
    DateOrReleaseBased,
    CapturedDate,
    CapturedRelease,
    MetricValue,
    ChartType
FROM
    (SELECT 
        project_name AS 'Project',
            metric_name AS 'MetricName',
            Date_or_Release_Based AS 'DateOrReleaseBased',
            SUBSTRING_INDEX(GROUP_CONCAT(DATE_FORMAT(Captured_Date, '%d-%b-%y')
                ORDER BY pm.Captured_Date DESC
                SEPARATOR ','), ',', 4) AS 'CapturedDate',
            SUBSTRING_INDEX(GROUP_CONCAT(Captured_Release
                ORDER BY pm.Created_Date DESC
                SEPARATOR ','), ',', 4) AS 'CapturedRelease',
            SUBSTRING_INDEX(GROUP_CONCAT(Metric_Value
                ORDER BY pm.Created_Date DESC
                SEPARATOR ','), ',', 4) AS 'MetricValue',
            chart_type AS 'ChartType'
    FROM
        program_master pmr
    INNER JOIN project_master p ON p.Aurora_Program_Seq_fk = pmr.Aurora_Program_Seq
    INNER JOIN project_metrics pm ON pm.Aurora_Project_Seq_pk_fk = p.Aurora_Project_Seq
    INNER JOIN metrics_master mm ON mm.Aurora_Metrics_Seq = pm.Aurora_Metrics_Seq_pk_fk
    WHERE
        program_name = 'ICG MHS -PS'
    GROUP BY project_name , metric_name) AS a;