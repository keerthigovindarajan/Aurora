SELECT 
    Project_Name AS Project,
    Risk_type AS 'RiskCategory',
    Risk_Identified As 'RiskIdentified',
    Risk_Indicator_Source AS 'RiskIdentifiedBy',
    Created_By AS 'RiskInitiator',
    DATE_FORMAT(Created_Date, '%d-%b-%y') AS 'RiskIdentifiedOn',
    Impact,
    Risk_Description AS 'RiskDescription',
    Remediation,
    Risk_Status AS Status,
    IFNull(Chorus_Alert_Id, 0) AS 'ChorusAlertID',
    DxT_Alert AS 'DxTAlert',
    rag_status_value AS RAG
FROM
    (SELECT 
        Program_Name,
            Aurora_Risk_Seq,
            Project_Name,
            Risk_type,
            GROUP_CONCAT(DISTINCT Risk_Indicator SEPARATOR ',') AS Risk_Identified,
            Risk_Indicator_Source,
            Created_By,
            Created_Date,
			GROUP_CONCAT(DISTINCT Impact_Type SEPARATOR ',') AS Impact,
            Risk_Description,
            Remediation,
            Risk_Status,
            Chorus_Alert_Id,
            DxT_Alert,
            rag_status_value,
			Severity_Level

    FROM
        (SELECT 
        pmr.Program_Name,
            pm.Project_Name,
            rl.Aurora_Risk_Seq,
            cm.risk_type,
            rimm.Risk_Indicator,
            rl.Risk_Indicator_Source,
            rl.Created_By,
            rl.Created_Date,
            im.Impact_Type,
            rl.Risk_Description,
            rl.Remediation,
            rl.Risk_Status,
            rl.Chorus_Alert_Id,
            rl.DxT_Alert,
            rs.rag_status_value,
            rs.Severity_Level
    FROM
        program_master pmr
    INNER JOIN project_master pm ON pm.Aurora_Program_Seq_fk = pmr.Aurora_Program_Seq
    INNER JOIN SEGMENT S ON S.Aurora_Segment_Seq = PM.Aurora_Segment_Seq_fk
    INNER JOIN risk_log rl ON pm.Aurora_Project_Seq = rl.Aurora_Project_Seq_fk
    INNER JOIN rag_status rs ON rl.Aurora_RAG_Status_Seq_fk = rs.Aurora_RAG_Status_Seq
    INNER JOIN risk_impact ri ON ri.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq
    INNER JOIN impact_master im ON im.Aurora_Impact_Category_Seq = ri.Aurora_Impact_Category_Seq_pk_fk
    INNER JOIN risk_log_indicator li ON li.Aurora_Risk_Seq_pk_fk = rl.Aurora_Risk_Seq
    INNER JOIN risk_indicator_master rim ON rim.Aurora_Risk_Indicator_Seq = li.Aurora_Risk_Indicator_Seq_pk_fk
    INNER JOIN risk_category_master cm ON cm.Aurora_Risk_Category_Seq = rim.Aurora_Risk_Category_Seq_fk
    INNER JOIN risk_indicator_master rimm ON rimm.Aurora_Risk_Category_Seq_fk = cm.Aurora_Risk_Category_Seq
    WHERE
        rl.risk_status = 'A') AS inner_query1
    GROUP BY Aurora_Risk_Seq
    HAVING inner_query1.Program_Name = "STaRS"
    ORDER BY Severity_Level DESC , Created_Date ASC) AS iq2
ORDER BY Severity_Level DESC , Created_Date ASC;