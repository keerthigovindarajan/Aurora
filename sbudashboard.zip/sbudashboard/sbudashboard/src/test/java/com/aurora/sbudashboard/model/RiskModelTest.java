package com.aurora.sbudashboard.model;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RiskModelTest {
	
	@InjectMocks
	RiskModel model = new RiskModel();
	
	@Before
	public void setUp() {
		model = new RiskModel();
		model.getCodeQualityandHighDefectsDensity();
		model.getCustomerCommitment();
		model.getCustomerProcess();
		model.getCustomerSLA();
		model.getEffortEstimates();
		model.getMilestoneAchievement();
		model.getProductivityBlueOptima();
		model.getProductivityDta();
		model.getProgram();
		model.getProjectComplexity();
		model.getProjectManagementRisk();
		model.getRequirementsStabilityorClarity();
		model.getResourceFullfillmentorStabilityorAttrition();
		model.getStatustrackingandreportingRigor();
		model.getSubContractingandVendorDeliverables();
		model.getTeamCompetencyandSkill();
		model.getTeamOrganizationandStructure();
		
	}
	@Test
	public void getScheduleEstimatesTest() {
		model.getScheduleEstimates();
	}

}
