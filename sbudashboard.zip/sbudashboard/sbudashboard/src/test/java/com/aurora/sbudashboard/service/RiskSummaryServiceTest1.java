package com.aurora.sbudashboard.service;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.aurora.sbudashboard.config.Constants;
import com.aurora.sbudashboard.dto.RiskSummaryDTO;
import com.aurora.sbudashboard.dtoimpl.RiskSummaryDTOImpl;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.RiskSummaryRepository;

@RunWith(MockitoJUnitRunner.class)
public class RiskSummaryServiceTest1 {

	@InjectMocks
	private RiskSummaryService service;
	@Mock
	private RiskSummaryRepository repository;

	List<RiskSummaryDTO> li1;
	RiskSummaryDTOImpl impl;
	List<RiskModel> li;
	RiskModel ri;
	Constants consts;

	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		service.setRepository(repository);
		li1 = new ArrayList<>();
		li = new ArrayList<>();
		consts = new Constants();
	}

	@Test
	public void getRiskSummaryTestCategory1() {
		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory("Project Complexity");
		impl.setProgram("stars");
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setProgram("stars");
		ri.setProjectComplexity(2);
		li.add(ri);
		// when(repository.getRiskSummaryDetails()).thenReturn(li1);
		// when(service.getRiskSummary()).thenReturn(li);
		// service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory2() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory("Status tracking & reporting Rigor");
		impl.setProgram("stars");
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setStatustrackingandreportingRigor(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory3() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory("Resource Fullfillment/Stability/Attrition");
		impl.setProgram("stars");
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setStatustrackingandreportingRigor(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory4() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.TEAM_COMPETENCY_AND_SKILL);
		impl.setProgram("stars");
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setTeamCompetencyandSkill(2);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory5() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.EFFORT_ESTIMATES);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setEffortEstimates(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory6() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.SCHEDULE_ESTIMATES);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setScheduleEstimates(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory7() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.REQUIREMENTS_STABILITY_OR_CLARITY);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setRequirementsStabilityorClarity(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory8() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.MILESTONE_ACHIEVEMENT);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setMilestoneAchievement(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory9() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CODE_QUALITY_AND_HIGH_DEFECTS_DENSITY);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setCodeQualityandHighDefectsDensity(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory10() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PRODUCTIVITY_BLUE_OPTIMA);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setProductivityBlueOptima(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory11() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PRODUCTIVITY_DTA);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setProductivityDta(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();
	}

	@Test
	public void getRiskSummaryTestCategory12() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CUSTOMER_SLA);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setCustomerSLA(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory13() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.PROJECT_MANAGEMENT_RISK);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setProjectManagementRisk(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory14() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.TEAM_ORGANIZATION_AND_STRUCTURE);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setTeamOrganizationandStructure(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory15() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.SUBCONTRACTING_AND_VENDOR_DELIVERABLES);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setSubContractingandVendorDeliverables(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory16() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CUSTOMER_COMMITMENT);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setCustomerCommitment(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

	@Test
	public void getRiskSummaryTestCategory17() {

		List<RiskSummaryDTO> li1 = new ArrayList<>();
		RiskSummaryDTOImpl impl = new RiskSummaryDTOImpl();
		impl.setCategory(consts.CUSTOMER_PROCESS);
		impl.setRisk(0);
		li1.add(impl);
		List<RiskModel> li = new ArrayList<>();
		RiskModel ri = new RiskModel();
		ri.setCustomerProcess(6);
		li.add(ri);
		when(repository.getRiskSummaryDetails()).thenReturn(li1);
		service.getRiskSummary();

	}

}