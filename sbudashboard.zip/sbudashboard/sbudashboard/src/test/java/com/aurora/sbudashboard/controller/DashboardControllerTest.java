package com.aurora.sbudashboard.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.CriticalRisksRepository;
import com.aurora.sbudashboard.service.RiskSummaryService;

@RunWith(MockitoJUnitRunner.class)

public class DashboardControllerTest {

	public DashboardControllerTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CriticalRisksDTO criticalRisksDTO;

	@InjectMocks
	DashboardController controller;
	@Mock
	private CriticalRisksRepository repo;
	@Mock
	private RiskSummaryService service;

	@Test
	public void openRisksDetailsTest() {

		List<CriticalRisksDTO> li = new ArrayList<>();
		li.add(criticalRisksDTO);
		controller.openRisksDetails();
	}

	@Test
	public void riskSummaryTest() {
		RiskModel riskmodel = new RiskModel();
		riskmodel.setCustomerSLA(2);
		List<RiskModel> li = new ArrayList<>();
		li.add(riskmodel);
		
		controller.riskSummary();

	}

}
