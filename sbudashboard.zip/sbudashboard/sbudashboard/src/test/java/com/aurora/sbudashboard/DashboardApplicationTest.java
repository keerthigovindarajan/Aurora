package com.aurora.sbudashboard;

import org.junit.Test;


public class DashboardApplicationTest {

	@Test
	public void main() {
		DashboardApplication.main(new String[] {});
	}

}
