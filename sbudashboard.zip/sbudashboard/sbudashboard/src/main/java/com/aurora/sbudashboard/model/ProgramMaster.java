package com.aurora.sbudashboard.model;

import java.sql.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="program_master")
public class ProgramMaster {
	@Id
	@Column(name = "Aurora_Program_Seq",columnDefinition = "int",nullable = false)
	private int auroraProgramSeq;
	
	
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public Date getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(Date createdBy) {
		this.createdBy = createdBy;
	}
	public Date getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(Date modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
	public Date getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(Date modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public void setProgramManager(String programManager) {
		this.programManager = programManager;
	}
	@Column(name = "Program_Name",columnDefinition = "varChar(100)",nullable = false)
	private String programName;
	
	@Column(name = "Program_Manager",columnDefinition = "varChar(100)",nullable = false)
	private String programManager;
	
	@Column(name = "Created_Date",nullable = false)
	private Date createdDate;
	
	@Column(name = "Created_By",columnDefinition = "varChar(100)",nullable = false)
	private Date createdBy;
	
	@Column(name = "Modified_Date",nullable = true)
	private Date modifiedDate;
	
	@Column(name = "Modified_By",columnDefinition = "varChar(100)",nullable = true)
	private Date modifiedBy;
	
	
	@OneToMany(mappedBy = "programMaster")
	private List<ProjectMaster> projects;
	
	public List<ProjectMaster> getProjects() {
		return projects;
	}
	public void setProjects(List<ProjectMaster> projects) {
		this.projects = projects;
	}
	
	public int getAuroraProgramSeq() {
		return auroraProgramSeq;
	}
	public void setAuroraProgramSeq(int auroraProgramSeq) {
		this.auroraProgramSeq = auroraProgramSeq;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgram_Name(String programName) {
		this.programName = programName;
	}
	public String getProgramManager() {
		return programManager;
	}
	public void setProgram_Manager(String programManager) {
		this.programManager = programManager;
	}
	

}
