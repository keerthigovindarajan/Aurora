package com.aurora.sbudashboard.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "project_master")
public class ProjectMaster {
	
	
	@Id
	@Column(name = "Aurora_Program_Seq",columnDefinition = "int",nullable = false)
	private int auroraProgramSeq;

	
	@Column(name = "Velocity_ProjectCode",columnDefinition = "int",nullable = false)
	private int velocityProjectCode;
	
	@Column(name = "Project_Name",columnDefinition = "varchar(100)",nullable = false)
	private String projectName;
	
	@Column(name = "Aurora_Segment_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraSegmentSeqfk;
	
	@Column(name = "Project_Status",columnDefinition = "varchar(10)",nullable = false)
	private String projectStatus;
	
	@Column(name = "Resources_Currently_Allocated",columnDefinition = "char(1)",nullable = false)
	private char resourcesCurrentlyAllocated;
	
	@Column(name = "Velocity_Start_Date",columnDefinition = "date",nullable = false)
	private Date velocityStartDate;
	
	@Column(name = "Velocity_End_Date",columnDefinition = "date",nullable = false)
	private Date velocityEndDate;
	
	@Column(name = "Virtusa_Segment_DeliveryHead",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaSegmentDeliveryHead;
	
	@Column(name = "Virtusa_DD_Name",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaDDName;
	
	@Column(name = "Virtusa_DD_EmailId",columnDefinition = "varchar(100)",nullable = true)
	private String virtusaDDEmailId;
	
	@Column(name = "Virtusa_PD_Name",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaPDName;
	
	@Column(name = "Virtusa_PD_EmailId",columnDefinition = "varchar(100)",nullable = true)
	private String virtusaPDEmailId;
	
	@Column(name = "Virtusa_PM_Name",columnDefinition = "varchar(100)",nullable = false)
	private String virtusaPMName;
	
	@Column(name = "Virtusa_PM_EmailId",columnDefinition = "varchar(100)",nullable = true)
	private String virtusaPMEmailId;
	
	@Column(name = "IT_Cluster",columnDefinition = "varchar(5)",nullable = true)
	private String itCluster;
	
	@Column(name = "Aurora_ServiceType_V_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraServiceTypeVSeqfk;
	
	@Column(name = "Aurora_Delivery_From_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraDeliveryFromSeqfk;
	
	@Column(name = "Pricing_Construct_Code_fk",columnDefinition = "varchar(10)",nullable = false)
	private String pricingConstructCodeFk;
	
	@Column(name = "Total_HC",columnDefinition = "int",nullable = false)
	private int totalHc;
	
	@Column(name = "HC_On",columnDefinition = "int",nullable = false)
	private int hcOn;
	
	@Column(name = "HC_Off",columnDefinition = "int",nullable = false)
	private int hcOff;
	
	@Column(name = "Recovery_Time_Objective",columnDefinition = "varchar(45)",nullable = true)
	private String recoveryTimeObjective;
	
	@Column(name = "Aurora_Program_Seq_fk",columnDefinition = "int",nullable = false)
	private int auroraProgramSeqfk;
	
	@Column(name = "Aurora_SOW_Seq_fk",columnDefinition = "varchar(15)")
	private String auroraSOWSeqfk;
	
	@Column(name = "Engagement_Plan_Applicability",columnDefinition = "varchar(30)",nullable = true)
	private String engagementPlanApplicability;
	
	@Column(name = "Engagement_Plan_Exemption_Reason",columnDefinition = "varchar(100)",nullable = true)
	private String engagementPlanExemptionReason;
	
	@Column(name = "SLA_Applicability",columnDefinition = "char(1)",nullable = true)
	private char slaApplicability;
	
	@Column(name = "KPI_Applicability",columnDefinition = "char(1)",nullable = true)
	private char KPI_Applicability;
	
	@Column(name = "Key_Personnel_Including_PM",columnDefinition = "int",nullable = true)
	private int Key_Personnel_Including_PM;
	
	@Column(name = "Project_Life_Cycle",columnDefinition = "varchar(45)",nullable = true)
	private String Project_Life_Cycle;
	
	@Column(name = "Project_Applicability_Secure_SDLC",columnDefinition = "char(1)",nullable = true)
	private char Project_Applicability_Secure_SDLC;
	
	@Column(name = "Project_Mobile_Development_Component",columnDefinition = "char(1)",nullable = true)
	private char Project_Mobile_Development_Component;
	
	@Column(name = "Release_Notes_Applicability",columnDefinition = "varchar(45)",nullable = true)
	private String Release_Notes_Applicability;
	
	@Column(name = "Self_Assessment_Applicability",columnDefinition = "varchar(45)",nullable = true)
	private String Self_Assessment_Applicability;
	
	@Column(name = "Governance_Report_Applicability",columnDefinition = "varchar(45)",nullable = true)
	private String Governance_Report_Applicability;
	
	@Column(name = "Governance_Report_Frequency",columnDefinition = "varchar(45)",nullable = true)
	private String Governance_Report_Frequency;
	
	@Column(name = "GDPR",columnDefinition = "varchar(45)",nullable = true)
	private String GDPR;
	
	@Column(name = "Remarks",columnDefinition = "varchar(100)",nullable = true)
	private String Remarks;
	
	@Column(name = "Highest_Confidentiality",columnDefinition = "varchar(20)",nullable = true)
	private String Highest_Confidentiality;
	
	@Column(name = "Created_Date",nullable = false)
	private Date Created_Date;
	
	@Column(name = "Created_By",columnDefinition = "varchar(100)",nullable = true)
	private String Created_By;
	
	@Column(name = "Modified_Date",nullable = true)
	private Date Modified_Date;
	
	@Column(name = "Modified_By",columnDefinition = "varchar(100)",nullable = true)
	private String Modified_By;
	
	
	
   /* @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name ="Program_Id_fk")
    private ProgramMaster programMaster;*/
	
	@ManyToOne
    @JoinColumn(name ="Aurora_Program_Seq_fk",insertable = false, updatable = false)
    private ProgramMaster programMaster;

   



	@ManyToOne
    @JoinColumn(name ="Aurora_Segment_Seq_fk",insertable = false, updatable = false)
    private Segment segment;
    
   

	public int getVelocityProjectCode() {
		return velocityProjectCode;
	}



	public void setVelocityProjectCode(int velocityProjectCode) {
		this.velocityProjectCode = velocityProjectCode;
	}



	public String getProjectName() {
		return projectName;
	}



	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}



	



	public String getProjectStatus() {
		return projectStatus;
	}



	public void setProjectStatus(String projectStatus) {
		this.projectStatus = projectStatus;
	}



	public char getResourcesCurrentlyAllocated() {
		return resourcesCurrentlyAllocated;
	}



	public void setResourcesCurrentlyAllocated(char resourcesCurrentlyAllocated) {
		this.resourcesCurrentlyAllocated = resourcesCurrentlyAllocated;
	}



	public Date getVelocityStartDate() {
		return velocityStartDate;
	}



	public void setVelocityStartDate(Date velocityStartDate) {
		this.velocityStartDate = velocityStartDate;
	}



	public Date getVelocityEndDate() {
		return velocityEndDate;
	}



	public void setVelocityEndDate(Date velocityEndDate) {
		this.velocityEndDate = velocityEndDate;
	}



	public String getVirtusaSegmentDeliveryHead() {
		return virtusaSegmentDeliveryHead;
	}



	public void setVirtusaSegmentDeliveryHead(String virtusaSegmentDeliveryHead) {
		this.virtusaSegmentDeliveryHead = virtusaSegmentDeliveryHead;
	}



	public String getVirtusaDDName() {
		return virtusaDDName;
	}



	public void setVirtusaDDName(String virtusaDDName) {
		this.virtusaDDName = virtusaDDName;
	}



	public String getVirtusaDDEmailId() {
		return virtusaDDEmailId;
	}



	public void setVirtusaDDEmailId(String virtusaDDEmailId) {
		this.virtusaDDEmailId = virtusaDDEmailId;
	}



	public String getVirtusaPDName() {
		return virtusaPDName;
	}



	public void setVirtusaPDName(String virtusaPDName) {
		this.virtusaPDName = virtusaPDName;
	}



	public String getVirtusaPDEmailId() {
		return virtusaPDEmailId;
	}



	public void setVirtusaPDEmailId(String virtusaPDEmailId) {
		this.virtusaPDEmailId = virtusaPDEmailId;
	}



	public String getVirtusaPMName() {
		return virtusaPMName;
	}



	public void setVirtusaPMName(String virtusaPMName) {
		this.virtusaPMName = virtusaPMName;
	}



	public String getVirtusaPMEmailId() {
		return virtusaPMEmailId;
	}



	public void setVirtusaPMEmailId(String virtusaPMEmailId) {
		this.virtusaPMEmailId = virtusaPMEmailId;
	}



	public String getItCluster() {
		return itCluster;
	}



	public void setItCluster(String itCluster) {
		this.itCluster = itCluster;
	}



	

	public String getPricingConstructCodeFk() {
		return pricingConstructCodeFk;
	}



	public void setPricingConstructCodeFk(String pricingConstructCodeFk) {
		this.pricingConstructCodeFk = pricingConstructCodeFk;
	}



	public int getTotalHc() {
		return totalHc;
	}



	public void setTotalHc(int totalHc) {
		this.totalHc = totalHc;
	}



	public int getHcOn() {
		return hcOn;
	}



	public void setHcOn(int hcOn) {
		this.hcOn = hcOn;
	}



	public int getHcOff() {
		return hcOff;
	}



	public void setHcOff(int hcOff) {
		this.hcOff = hcOff;
	}



	public String getRecoveryTimeObjective() {
		return recoveryTimeObjective;
	}



	public void setRecoveryTimeObjective(String recoveryTimeObjective) {
		this.recoveryTimeObjective = recoveryTimeObjective;
	}



	

	public String getEngagementPlanApplicability() {
		return engagementPlanApplicability;
	}



	public void setEngagementPlanApplicability(String engagementPlanApplicability) {
		this.engagementPlanApplicability = engagementPlanApplicability;
	}



	public String getEngagementPlanExemptionReason() {
		return engagementPlanExemptionReason;
	}



	public void setEngagementPlanExemptionReason(String engagementPlanExemptionReason) {
		this.engagementPlanExemptionReason = engagementPlanExemptionReason;
	}



	public char getSlaApplicability() {
		return slaApplicability;
	}



	public void setSlaApplicability(char slaApplicability) {
		this.slaApplicability = slaApplicability;
	}



	public char getKPI_Applicability() {
		return KPI_Applicability;
	}



	public void setKPI_Applicability(char kPI_Applicability) {
		KPI_Applicability = kPI_Applicability;
	}



	public int getKey_Personnel_Including_PM() {
		return Key_Personnel_Including_PM;
	}



	public void setKey_Personnel_Including_PM(int key_Personnel_Including_PM) {
		Key_Personnel_Including_PM = key_Personnel_Including_PM;
	}



	public String getProject_Life_Cycle() {
		return Project_Life_Cycle;
	}



	public void setProject_Life_Cycle(String project_Life_Cycle) {
		Project_Life_Cycle = project_Life_Cycle;
	}



	public char getProject_Applicability_Secure_SDLC() {
		return Project_Applicability_Secure_SDLC;
	}



	public void setProject_Applicability_Secure_SDLC(char project_Applicability_Secure_SDLC) {
		Project_Applicability_Secure_SDLC = project_Applicability_Secure_SDLC;
	}



	public char getProject_Mobile_Development_Component() {
		return Project_Mobile_Development_Component;
	}



	public void setProject_Mobile_Development_Component(char project_Mobile_Development_Component) {
		Project_Mobile_Development_Component = project_Mobile_Development_Component;
	}



	public String getRelease_Notes_Applicability() {
		return Release_Notes_Applicability;
	}



	public void setRelease_Notes_Applicability(String release_Notes_Applicability) {
		Release_Notes_Applicability = release_Notes_Applicability;
	}



	public String getSelf_Assessment_Applicability() {
		return Self_Assessment_Applicability;
	}



	public void setSelf_Assessment_Applicability(String self_Assessment_Applicability) {
		Self_Assessment_Applicability = self_Assessment_Applicability;
	}



	public String getGovernance_Report_Applicability() {
		return Governance_Report_Applicability;
	}



	public void setGovernance_Report_Applicability(String governance_Report_Applicability) {
		Governance_Report_Applicability = governance_Report_Applicability;
	}



	public String getGovernance_Report_Frequency() {
		return Governance_Report_Frequency;
	}



	public void setGovernance_Report_Frequency(String governance_Report_Frequency) {
		Governance_Report_Frequency = governance_Report_Frequency;
	}



	public String getGDPR() {
		return GDPR;
	}



	public void setGDPR(String gDPR) {
		GDPR = gDPR;
	}



	public String getRemarks() {
		return Remarks;
	}



	public void setRemarks(String remarks) {
		Remarks = remarks;
	}



	public String getHighest_Confidentiality() {
		return Highest_Confidentiality;
	}



	public void setHighest_Confidentiality(String highest_Confidentiality) {
		Highest_Confidentiality = highest_Confidentiality;
	}



	public Date getCreated_Date() {
		return Created_Date;
	}



	public void setCreated_Date(Date created_Date) {
		Created_Date = created_Date;
	}



	public String getCreated_By() {
		return Created_By;
	}



	public void setCreated_By(String created_By) {
		Created_By = created_By;
	}



	public Date getModified_Date() {
		return Modified_Date;
	}



	public void setModified_Date(Date modified_Date) {
		Modified_Date = modified_Date;
	}



	public String getModified_By() {
		return Modified_By;
	}



	public void setModified_By(String modified_By) {
		Modified_By = modified_By;
	}



	public ProgramMaster getProgramMaster() {
		return programMaster;
	}



	public void setProgramMaster(ProgramMaster programMaster) {
		this.programMaster = programMaster;
	}

	public int getAuroraProgramSeq() {
		return auroraProgramSeq;
	}



	public void setAuroraProgramSeq(int auroraProgramSeq) {
		this.auroraProgramSeq = auroraProgramSeq;
	}



	public int getAuroraSegmentSeqfk() {
		return auroraSegmentSeqfk;
	}



	public void setAuroraSegmentSeqfk(int auroraSegmentSeqfk) {
		this.auroraSegmentSeqfk = auroraSegmentSeqfk;
	}



	public int getAuroraServiceTypeVSeqfk() {
		return auroraServiceTypeVSeqfk;
	}



	public void setAuroraServiceTypeVSeqfk(int auroraServiceTypeVSeqfk) {
		this.auroraServiceTypeVSeqfk = auroraServiceTypeVSeqfk;
	}



	public int getAuroraDeliveryFromSeqfk() {
		return auroraDeliveryFromSeqfk;
	}



	public void setAuroraDeliveryFromSeqfk(int auroraDeliveryFromSeqfk) {
		this.auroraDeliveryFromSeqfk = auroraDeliveryFromSeqfk;
	}



	public int getAuroraProgramSeqfk() {
		return auroraProgramSeqfk;
	}



	public void setAuroraProgramSeqfk(int auroraProgramSeqfk) {
		this.auroraProgramSeqfk = auroraProgramSeqfk;
	}



	public String getAuroraSOWSeqfk() {
		return auroraSOWSeqfk;
	}



	public void setAuroraSOWSeqfk(String auroraSOWSeqfk) {
		this.auroraSOWSeqfk = auroraSOWSeqfk;
	}

	 public Segment getSegment() {
			return segment;
		}



		public void setSegment(Segment segment) {
			this.segment = segment;
		}

	@Override
	public String toString() {
		return "ProjectMaster [auroraProgramSeq=" + auroraProgramSeq + ", velocityProjectCode=" + velocityProjectCode
				+ ", projectName=" + projectName + ", auroraSegmentSeqfk=" + auroraSegmentSeqfk + ", projectStatus="
				+ projectStatus + ", resourcesCurrentlyAllocated=" + resourcesCurrentlyAllocated
				+ ", velocityStartDate=" + velocityStartDate + ", velocityEndDate=" + velocityEndDate
				+ ", virtusaSegmentDeliveryHead=" + virtusaSegmentDeliveryHead + ", virtusaDDName=" + virtusaDDName
				+ ", virtusaDDEmailId=" + virtusaDDEmailId + ", virtusaPDName=" + virtusaPDName + ", virtusaPDEmailId="
				+ virtusaPDEmailId + ", virtusaPMName=" + virtusaPMName + ", virtusaPMEmailId=" + virtusaPMEmailId
				+ ", itCluster=" + itCluster + ", auroraServiceTypeVSeqfk=" + auroraServiceTypeVSeqfk
				+ ", auroraDeliveryFromSeqfk=" + auroraDeliveryFromSeqfk + ", pricingConstructCodeFk="
				+ pricingConstructCodeFk + ", totalHc=" + totalHc + ", hcOn=" + hcOn + ", hcOff=" + hcOff
				+ ", recoveryTimeObjective=" + recoveryTimeObjective + ", auroraProgramSeqfk=" + auroraProgramSeqfk
				+ ", auroraSOWSeqfk=" + auroraSOWSeqfk + ", engagementPlanApplicability=" + engagementPlanApplicability
				+ ", engagementPlanExemptionReason=" + engagementPlanExemptionReason + ", slaApplicability="
				+ slaApplicability + ", KPI_Applicability=" + KPI_Applicability + ", Key_Personnel_Including_PM="
				+ Key_Personnel_Including_PM + ", Project_Life_Cycle=" + Project_Life_Cycle
				+ ", Project_Applicability_Secure_SDLC=" + Project_Applicability_Secure_SDLC
				+ ", Project_Mobile_Development_Component=" + Project_Mobile_Development_Component
				+ ", Release_Notes_Applicability=" + Release_Notes_Applicability + ", Self_Assessment_Applicability="
				+ Self_Assessment_Applicability + ", Governance_Report_Applicability=" + Governance_Report_Applicability
				+ ", Governance_Report_Frequency=" + Governance_Report_Frequency + ", GDPR=" + GDPR + ", Remarks="
				+ Remarks + ", Highest_Confidentiality=" + Highest_Confidentiality + ", Created_Date=" + Created_Date
				+ ", Created_By=" + Created_By + ", Modified_Date=" + Modified_Date + ", Modified_By=" + Modified_By
				+ ", programMaster=" + programMaster + ", segment=" + segment + "]";
	}



    
   

}
