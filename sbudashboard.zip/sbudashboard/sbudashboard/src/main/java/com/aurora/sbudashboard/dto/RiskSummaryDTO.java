package com.aurora.sbudashboard.dto;

public interface RiskSummaryDTO {

	String getProgram();
	String getCategory();
	Integer getRisk();
	 
	void setProgram(String program);
	void setCategory(String category);
	void setRisk(int risk);
	
}
