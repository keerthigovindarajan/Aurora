package com.aurora.sbudashboard.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aurora.sbudashboard.config.Constants;
import com.aurora.sbudashboard.dto.RiskSummaryDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.RiskSummaryRepository;

@Service
public class RiskSummaryService { 

	/**
	 * 
	 */
	@Autowired
	private RiskSummaryRepository repository;

	public void setRepository(RiskSummaryRepository repository) {
		this.repository = repository;
	}

	public List<RiskModel> getRiskSummary() {

		List<RiskSummaryDTO> dto = repository.getRiskSummaryDetails();

		RiskModel ri = new RiskModel();
		List<RiskModel> lir = new ArrayList<>();

		int i = 0,count=0;
		for (RiskSummaryDTO rm : dto) {
			
			

			if (lir.isEmpty()) {
				ri = new RiskModel();
				ri.setProgram(rm.getProgram());
				if (rm.getCategory().equalsIgnoreCase(Constants.PROJECT_COMPLEXITY)) {
					ri.setProjectComplexity(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.STATUS_TRACKING_AND_REPORTING_RIGOR)) {
					ri.setStatustrackingandreportingRigor(rm.getRisk());


				} else if (rm.getCategory()
						.equalsIgnoreCase(Constants.RESOURCE_FULLFILLMENT_OR_STABILITY_OR_ATTRITION)) {
					ri.setResourceFullfillmentorStabilityorAttrition(rm.getRisk());


				} else if (rm.getCategory().equalsIgnoreCase(Constants.TEAM_COMPETENCY_AND_SKILL)) {
					ri.setTeamCompetencyandSkill(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.EFFORT_ESTIMATES)) {
					ri.setEffortEstimates(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.SCHEDULE_ESTIMATES)) {
					ri.setScheduleEstimates(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.REQUIREMENTS_STABILITY_OR_CLARITY)) {
					ri.setRequirementsStabilityorClarity(rm.getRisk());


				} else if (rm.getCategory().equalsIgnoreCase(Constants.MILESTONE_ACHIEVEMENT)) {
					ri.setMilestoneAchievement(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.CODE_QUALITY_AND_HIGH_DEFECTS_DENSITY)) {
					ri.setCodeQualityandHighDefectsDensity(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.PRODUCTIVITY_BLUE_OPTIMA)) {
					ri.setProductivityBlueOptima(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.PRODUCTIVITY_DTA)) {
					ri.setProductivityDta(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_SLA)) {
					ri.setCustomerSLA(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.PROJECT_MANAGEMENT_RISK)) {
					ri.setProjectManagementRisk(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.TEAM_ORGANIZATION_AND_STRUCTURE)) {
					ri.setTeamOrganizationandStructure(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.SUBCONTRACTING_AND_VENDOR_DELIVERABLES)) {
					ri.setSubContractingandVendorDeliverables(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_COMMITMENT)) {
					ri.setCustomerCommitment(rm.getRisk());

				} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_PROCESS)) {
					ri.setCustomerProcess(rm.getRisk());
				}
				lir.add(ri);

			}

			else {

				for (i = lir.size() - 1; i < lir.size();) {
					if (!(lir.get(i).getProgram().equalsIgnoreCase(rm.getProgram()))) {
						ri = new RiskModel();
						ri.setProgram(rm.getProgram());

						if (rm.getCategory().equalsIgnoreCase(Constants.PROJECT_COMPLEXITY)) {
							ri.setProjectComplexity(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.STATUS_TRACKING_AND_REPORTING_RIGOR)) {
							ri.setStatustrackingandreportingRigor(rm.getRisk());

						} else if (rm.getCategory()
								.equalsIgnoreCase(Constants.RESOURCE_FULLFILLMENT_OR_STABILITY_OR_ATTRITION)) {
							ri.setResourceFullfillmentorStabilityorAttrition(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.TEAM_COMPETENCY_AND_SKILL)) {
							ri.setTeamCompetencyandSkill(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.EFFORT_ESTIMATES)) {
							ri.setEffortEstimates(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.SCHEDULE_ESTIMATES)) {
							ri.setScheduleEstimates(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.REQUIREMENTS_STABILITY_OR_CLARITY)) {
							ri.setRequirementsStabilityorClarity(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.MILESTONE_ACHIEVEMENT)) {
							ri.setMilestoneAchievement(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CODE_QUALITY_AND_HIGH_DEFECTS_DENSITY)) {
							ri.setCodeQualityandHighDefectsDensity(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.PRODUCTIVITY_BLUE_OPTIMA)) {
							ri.setProductivityBlueOptima(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.PRODUCTIVITY_DTA)) {
							ri.setProductivityDta(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_SLA)) {
							ri.setCustomerSLA(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.PROJECT_MANAGEMENT_RISK)) {
							ri.setProjectManagementRisk(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.TEAM_ORGANIZATION_AND_STRUCTURE)) {
							ri.setTeamOrganizationandStructure(rm.getRisk());

						} else if (rm.getCategory()
								.equalsIgnoreCase(Constants.SUBCONTRACTING_AND_VENDOR_DELIVERABLES)) {
							ri.setSubContractingandVendorDeliverables(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_COMMITMENT)) {
							ri.setCustomerCommitment(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_PROCESS)) {
							ri.setCustomerProcess(rm.getRisk());
						}
						lir.add(ri);
						break;

					} else {
						if (rm.getCategory().equalsIgnoreCase(Constants.PROJECT_COMPLEXITY)) {
							ri.setProjectComplexity(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.STATUS_TRACKING_AND_REPORTING_RIGOR)) {
							ri.setStatustrackingandreportingRigor(rm.getRisk());


						} else if (rm.getCategory()
								.equalsIgnoreCase(Constants.RESOURCE_FULLFILLMENT_OR_STABILITY_OR_ATTRITION)) {
							ri.setResourceFullfillmentorStabilityorAttrition(rm.getRisk());


						} else if (rm.getCategory().equalsIgnoreCase(Constants.TEAM_COMPETENCY_AND_SKILL)) {
							ri.setTeamCompetencyandSkill(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.EFFORT_ESTIMATES)) {
							ri.setEffortEstimates(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.SCHEDULE_ESTIMATES)) {
							ri.setScheduleEstimates(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.REQUIREMENTS_STABILITY_OR_CLARITY)) {
							ri.setRequirementsStabilityorClarity(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.MILESTONE_ACHIEVEMENT)) {
							ri.setMilestoneAchievement(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CODE_QUALITY_AND_HIGH_DEFECTS_DENSITY)) {
							ri.setCodeQualityandHighDefectsDensity(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.PRODUCTIVITY_BLUE_OPTIMA)) {
							ri.setProductivityBlueOptima(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.PRODUCTIVITY_DTA)) {
							ri.setProductivityDta(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_SLA)) {
							ri.setCustomerSLA(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.PROJECT_MANAGEMENT_RISK)) {
							ri.setProjectManagementRisk(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.TEAM_ORGANIZATION_AND_STRUCTURE)) {
							ri.setTeamOrganizationandStructure(rm.getRisk());

						} else if (rm.getCategory()
								.equalsIgnoreCase(Constants.SUBCONTRACTING_AND_VENDOR_DELIVERABLES)) {
							ri.setSubContractingandVendorDeliverables(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_COMMITMENT)) {
							ri.setCustomerCommitment(rm.getRisk());

						} else if (rm.getCategory().equalsIgnoreCase(Constants.CUSTOMER_PROCESS)) {
							ri.setCustomerProcess(rm.getRisk());
						}
						break;
					}
				}
			}
		}

		return lir;

	}

}
