package com.aurora.sbudashboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.repository.DashboardRepository;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/citi-portal")
public class DashboardController {
	@Autowired
	private DashboardRepository repo;
	

	@GetMapping("/criticalRisks")
	public @ResponseBody List<CriticalRisksDTO> openRisksDetails() {

		return repo.getCustomerDetails();
	}



}
