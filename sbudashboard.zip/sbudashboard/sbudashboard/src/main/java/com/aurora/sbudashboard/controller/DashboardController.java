package com.aurora.sbudashboard.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aurora.sbudashboard.dto.CriticalRisksDTO;
import com.aurora.sbudashboard.model.RiskModel;
import com.aurora.sbudashboard.repository.CriticalRisksRepository;
import com.aurora.sbudashboard.service.RiskSummaryService;

@RestController
@CrossOrigin("*") 
@RequestMapping("/api/citi-portal")
public class DashboardController {

	private final Logger log = LoggerFactory.getLogger(this.getClass());

	@Autowired
	private CriticalRisksRepository repo;
	@Autowired
	private RiskSummaryService service;

	@GetMapping("/criticalRisks")
	public ResponseEntity<List<CriticalRisksDTO>> openRisksDetails() {

		log.info("Request has been made to get the List of Critical Open Risks");
		List<CriticalRisksDTO> dto = repo.getCriticalRisksDetails();
		return new ResponseEntity<List<CriticalRisksDTO>>(dto, HttpStatus.OK);

	}

	@GetMapping("/riskSummary")
	public ResponseEntity<List<RiskModel>> riskSummary() {
		log.info("Request has been made to get the List of Program-wise Risk Summary");

		List<RiskModel> dto = service.getRiskSummary();
		
		return new ResponseEntity<List<RiskModel>>(dto, HttpStatus.OK);

	}

}
